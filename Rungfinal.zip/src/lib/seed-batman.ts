import { makeTiers } from "@/lib/templates";
import type { Board, Item } from "@/lib/types";
import { UNRANKED } from "@/lib/types";

export const BATMAN_BOARD_ID = "rung-seed-batman-movies";

type Film = {
  id: string;
  label: string;
  imageUrl: string;
  sourceUrl: string;
};

const FILMS: Film[] = [
  {
    id: "bat-1966",
    label: "Batman (1966)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/6/69/Batman1966Poster.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman_(1966_film)",
  },
  {
    id: "bat-1989",
    label: "Batman (1989)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/5/5a/Batman_%281989%29_theatrical_poster.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman_(1989_film)",
  },
  {
    id: "bat-returns",
    label: "Batman Returns (1992)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/8/83/Batman_returns_poster2.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman_Returns",
  },
  {
    id: "bat-phantasm",
    label: "Batman: Mask of the Phantasm (1993)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/e/ea/Batman_mask_of_the_phantasm_poster.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman:_Mask_of_the_Phantasm",
  },
  {
    id: "bat-forever",
    label: "Batman Forever (1995)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/9/9d/Batman_Forever_poster.png",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman_Forever",
  },
  {
    id: "bat-robin",
    label: "Batman & Robin (1997)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/3/37/Batman_%26_Robin_poster.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman_%26_Robin_(film)",
  },
  {
    id: "bat-subzero",
    label: "Batman & Mr. Freeze: SubZero (1998)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/4/47/Batman_%26_Mr._Freeze_SubZero.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman_%26_Mr._Freeze:_SubZero",
  },
  {
    id: "bat-beyond-joker",
    label: "Batman Beyond: Return of the Joker (2000)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/f/fd/Batman_Beyond_-_Return_of_the_Joker_poster.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman_Beyond:_Return_of_the_Joker",
  },
  {
    id: "bat-batwoman",
    label: "Batman: Mystery of the Batwoman (2003)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/7/7f/Batman-Mystery_of_the_Batwoman_poster.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman:_Mystery_of_the_Batwoman",
  },
  {
    id: "bat-begins",
    label: "Batman Begins (2005)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/a/af/Batman_Begins_Poster.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman_Begins",
  },
  {
    id: "bat-dracula",
    label: "The Batman vs. Dracula (2005)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/2/2f/Batman_vs._Dracula.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/The_Batman_vs._Dracula",
  },
  {
    id: "bat-tdk",
    label: "The Dark Knight (2008)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/1/1c/The_Dark_Knight_%282008_film%29.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/The_Dark_Knight",
  },
  {
    id: "bat-gotham-knight",
    label: "Batman: Gotham Knight (2008)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/f/f0/Batman_Gotham_Knight.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman:_Gotham_Knight",
  },
  {
    id: "bat-public-enemies",
    label: "Superman/Batman: Public Enemies (2009)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/9/9f/Sup_bat_public_enemies_dvd.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Superman/Batman:_Public_Enemies",
  },
  {
    id: "bat-red-hood",
    label: "Batman: Under the Red Hood (2010)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/4/4c/Batman_under_the_red_hood_poster.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman:_Under_the_Red_Hood",
  },
  {
    id: "bat-apocalypse",
    label: "Superman/Batman: Apocalypse (2010)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/f/f2/SBApocalypse.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Superman/Batman:_Apocalypse",
  },
  {
    id: "bat-year-one",
    label: "Batman: Year One (2011)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/8/8b/Bat_year_one_film.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman:_Year_One_(film)",
  },
  {
    id: "bat-tdkr",
    label: "The Dark Knight Rises (2012)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/8/83/Dark_knight_rises_poster.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/The_Dark_Knight_Rises",
  },
  {
    id: "bat-dkr-1",
    label: "Batman: The Dark Knight Returns, Part 1 (2012)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/e/e9/Batman_The_Dark_Knight_Returns_%28film%29.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman:_The_Dark_Knight_Returns_(film)",
  },
  {
    id: "bat-dkr-2",
    label: "Batman: The Dark Knight Returns, Part 2 (2013)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/e/e9/Batman_The_Dark_Knight_Returns_%28film%29.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman:_The_Dark_Knight_Returns_(film)",
  },
  {
    id: "bat-lego-unite",
    label: "LEGO Batman: DC Super Heroes Unite (2013)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/4/43/Legobatman2.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Lego_Batman:_The_Movie_–_DC_Super_Heroes_Unite",
  },
  {
    id: "bat-son",
    label: "Son of Batman (2014)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/2/21/Son_of_Batman_cover.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Son_of_Batman",
  },
  {
    id: "bat-arkham",
    label: "Batman: Assault on Arkham (2014)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/c/c0/Batman_Assault_on_Arkham_cover.jpeg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman:_Assault_on_Arkham",
  },
  {
    id: "bat-vs-robin",
    label: "Batman vs. Robin (2015)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/0/00/Bat_vs_robin_cover.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman_vs._Robin",
  },
  {
    id: "bat-unl-animal",
    label: "Batman Unlimited: Animal Instincts (2015)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/4/43/Batman_animal_instincts.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman_Unlimited:_Animal_Instincts",
  },
  {
    id: "bat-unl-monster",
    label: "Batman Unlimited: Monster Mayhem (2015)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/7/70/Batman_monster_mayhem.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman_Unlimited:_Monster_Mayhem",
  },
  {
    id: "bat-bvs",
    label: "Batman v Superman: Dawn of Justice (2016)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/3/31/Batman_v_Superman_Dawn_of_Justice_poster.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman_v_Superman:_Dawn_of_Justice",
  },
  {
    id: "bat-bad-blood",
    label: "Batman: Bad Blood (2016)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/d/df/Batman_Bad_Blood_cover.jpeg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman:_Bad_Blood",
  },
  {
    id: "bat-killing-joke",
    label: "Batman: The Killing Joke (2016)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/1/11/Batman-The_Killing_Joke_%28film%29.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman:_The_Killing_Joke_(film)",
  },
  {
    id: "bat-unl-mechs",
    label: "Batman Unlimited: Mechs vs. Mutants (2016)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/8/8a/Mechs-vs-Mutants-2D-600x790.jpeg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman_Unlimited:_Mechs_vs._Mutants",
  },
  {
    id: "bat-caped-crusaders",
    label: "Batman: Return of the Caped Crusaders (2016)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/c/cb/Batman-_Return_of_the_Caped_Crusaders.jpeg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman:_Return_of_the_Caped_Crusaders",
  },
  {
    id: "bat-jl",
    label: "Justice League (2017)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/6/6b/Justice_League_%28film%29_poster.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Justice_League_(film)",
  },
  {
    id: "bat-lego",
    label: "The Lego Batman Movie (2017)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/6/61/The_Lego_Batman_Movie_PromotionalPoster.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/The_Lego_Batman_Movie",
  },
  {
    id: "bat-harley",
    label: "Batman and Harley Quinn (2017)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/b/b9/Batman_and_Harley_Quinn_movie_poster.jpeg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman_and_Harley_Quinn",
  },
  {
    id: "bat-two-face",
    label: "Batman vs. Two-Face (2017)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/d/da/Batman_vs_Two-Face_cover.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman_vs._Two-Face",
  },
  {
    id: "bat-scooby",
    label: "Scooby-Doo! & Batman: The Brave and the Bold (2018)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/9/9e/SCOOBY_BM_BATB_AMRY_2D_1000692058.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Scooby-Doo!_%26_Batman:_The_Brave_and_the_Bold",
  },
  {
    id: "bat-gaslight",
    label: "Batman: Gotham by Gaslight (2018)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/c/cf/Gotham_gaslight_blueray.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman:_Gotham_by_Gaslight",
  },
  {
    id: "bat-ninja",
    label: "Batman Ninja (2018)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/9/91/Batman-ninja---blu-ray-cover-1518549457339_1280w.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman_Ninja",
  },
  {
    id: "bat-joker",
    label: "Joker (2019)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/e/e1/Joker_%282019_film%29_poster.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Joker_(2019_film)",
  },
  {
    id: "bat-tmnt",
    label: "Batman vs. Teenage Mutant Ninja Turtles (2019)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/1/19/Batman_Ninja_Turtles_Cover.png",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman_vs._Teenage_Mutant_Ninja_Turtles",
  },
  {
    id: "bat-hush",
    label: "Batman: Hush (2019)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/e/e0/Batman_Hush_4K_Ultra_HD_Blu-ray_cover.jpeg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman:_Hush_(film)",
  },
  {
    id: "bat-family-matters",
    label: "LEGO DC Batman: Family Matters (2019)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/6/62/Batman_lego_family_matters.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Lego_DC_Batman:_Family_Matters",
  },
  {
    id: "bat-ditf",
    label: "Batman: Death in the Family (2020)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/2/2d/Batman_Death_in_the_Family.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman:_Death_in_the_Family",
  },
  {
    id: "bat-zsjl",
    label: "Zack Snyder's Justice League (2021)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/6/60/Zack_Snyder%27s_Justice_League.png",
    sourceUrl: "https://en.wikipedia.org/wiki/Zack_Snyder's_Justice_League",
  },
  {
    id: "bat-soul",
    label: "Batman: Soul of the Dragon (2021)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/e/e7/Batman_Soul_of_the_Dragon_film_Blu-ray.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman:_Soul_of_the_Dragon",
  },
  {
    id: "bat-tlh-1",
    label: "Batman: The Long Halloween, Part One (2021)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/0/0a/Batman_The_Long_Halloween_4k.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman:_The_Long_Halloween_(film)",
  },
  {
    id: "bat-tlh-2",
    label: "Batman: The Long Halloween, Part Two (2021)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/0/0a/Batman_The_Long_Halloween_4k.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman:_The_Long_Halloween_(film)",
  },
  {
    id: "bat-2022",
    label: "The Batman (2022)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/f/ff/The_Batman_%28film%29_poster.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/The_Batman_(film)",
  },
  {
    id: "bat-super-sons",
    label: "Batman and Superman: Battle of the Super Sons (2022)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/c/c1/Batman_and_Superman_Battle_of_the_Super_Sons_poster.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman_and_Superman:_Battle_of_the_Super_Sons",
  },
  {
    id: "bat-flash",
    label: "The Flash (2023)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/e/ed/The_Flash_%28film%29_poster.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/The_Flash_(film)",
  },
  {
    id: "bat-doom",
    label: "Batman: The Doom That Came to Gotham (2023)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/1/10/Batman_The_Doom_That_Came_to_Gotham_issue_1.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman:_The_Doom_That_Came_to_Gotham",
  },
  {
    id: "bat-merry",
    label: "Merry Little Batman (2023)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/1/16/Merry_Little_Batman_poster.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Merry_Little_Batman",
  },
  {
    id: "bat-folie",
    label: "Joker: Folie à Deux (2024)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/e/e8/Joker_-_Folie_%C3%A0_Deux_poster.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Joker:_Folie_à_Deux",
  },
  {
    id: "bat-aztec",
    label: "Aztec Batman: Clash of Empires (2025)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/e/e9/Aztec_Batman_Clash_of_Empires_poster.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Aztec_Batman:_Clash_of_Empires",
  },
  {
    id: "bat-yakuza",
    label: "Batman Ninja vs. Yakuza League (2025)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/3/3b/Batman_Ninja_vs._Yakuza_League_poster.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman_Ninja_vs._Yakuza_League",
  },
  {
    id: "bat-knightfall",
    label: "Batman: Knightfall Part 1 (2026)",
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/9/90/BatmanKnightfallTrilogyLogo.jpg",
    sourceUrl: "https://en.wikipedia.org/wiki/Batman:_Knightfall_(film)",
  },
];

export function buildBatmanBoard(): Board {
  const now = Date.now();
  const tiers = makeTiers("classic");
  const items: Record<string, Item> = {};
  const order: string[] = [];
  for (const film of FILMS) {
    items[film.id] = {
      id: film.id,
      label: film.label,
      imageUrl: film.imageUrl,
      sourceUrl: film.sourceUrl,
    };
    order.push(film.id);
  }
  const placements: Record<string, string[]> = { [UNRANKED]: order };
  for (const tier of tiers) placements[tier.id] = [];
  return {
    id: BATMAN_BOARD_ID,
    title: "Batman movies",
    createdAt: now,
    updatedAt: now,
    tiers,
    items,
    placements,
  };
}
