export const UNRANKED = "unranked";

export type Tier = {
  id: string;
  name: string;
  color: string;
};

export type Item = {
  id: string;
  label: string;
  imageUrl: string | null;
  sourceUrl?: string;
};

export type Board = {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  tiers: Tier[];
  items: Record<string, Item>;
  placements: Record<string, string[]>;
};

export type DropZone = string;
