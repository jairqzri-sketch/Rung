const INK = "#161412";
const PAPER = "#f7f4ee";

export function parseHex(hex: string): { r: number; g: number; b: number } | null {
  const raw = hex.replace("#", "").trim();
  const full =
    raw.length === 3
      ? raw
          .split("")
          .map((c) => c + c)
          .join("")
      : raw;
  if (!/^[0-9a-fA-F]{6}$/.test(full)) return null;
  return {
    r: Number.parseInt(full.slice(0, 2), 16),
    g: Number.parseInt(full.slice(2, 4), 16),
    b: Number.parseInt(full.slice(4, 6), 16),
  };
}

export function onColor(hex: string): string {
  const rgb = parseHex(hex);
  if (!rgb) return INK;
  const y = (0.2126 * rgb.r + 0.7152 * rgb.g + 0.0722 * rgb.b) / 255;
  return y > 0.58 ? INK : PAPER;
}

export const TIER_SWATCHES = [
  "#e85d4c",
  "#e89a4c",
  "#e8c84c",
  "#7dbe6a",
  "#5aa0d6",
  "#8b86a8",
  "#d46a8a",
  "#c45c26",
  "#2f9e7b",
  "#3d6ea8",
  "#6b5b95",
  "#4a4a4e",
] as const;
