export type ImageHit = {
  id: string;
  title: string;
  thumbUrl: string;
  fullUrl: string;
  source: "wikipedia" | "commons";
};

const UA_HEADERS = {
  Accept: "application/json",
};

function wikiApi(host: "en.wikipedia.org" | "commons.wikimedia.org") {
  return `https://${host}/w/api.php`;
}

type WikiPage = {
  pageid?: number;
  title?: string;
  thumbnail?: { source?: string };
  original?: { source?: string };
  imageinfo?: Array<{
    thumburl?: string;
    url?: string;
    mime?: string;
  }>;
};

async function fetchJson(url: URL): Promise<unknown> {
  const response = await fetch(url.toString(), {
    headers: UA_HEADERS,
  });
  if (!response.ok) {
    throw new Error(`Search failed (${response.status})`);
  }
  return response.json();
}

function pagesFrom(payload: unknown): WikiPage[] {
  if (!payload || typeof payload !== "object") return [];
  const query = (payload as { query?: { pages?: Record<string, WikiPage> } }).query;
  if (!query?.pages) return [];
  return Object.values(query.pages).sort((a, b) => {
    const ai = (a as { index?: number }).index ?? 0;
    const bi = (b as { index?: number }).index ?? 0;
    return ai - bi;
  });
}

async function searchWikipedia(query: string): Promise<ImageHit[]> {
  const url = new URL(wikiApi("en.wikipedia.org"));
  url.searchParams.set("action", "query");
  url.searchParams.set("format", "json");
  url.searchParams.set("origin", "*");
  url.searchParams.set("generator", "search");
  url.searchParams.set("gsrsearch", query);
  url.searchParams.set("gsrlimit", "18");
  url.searchParams.set("prop", "pageimages");
  url.searchParams.set("piprop", "thumbnail|original");
  url.searchParams.set("pithumbsize", "400");

  const pages = pagesFrom(await fetchJson(url));
  const hits: ImageHit[] = [];
  for (const page of pages) {
    const thumb = page.thumbnail?.source;
    if (!thumb) continue;
    hits.push({
      id: `wiki-${page.pageid ?? page.title ?? thumb}`,
      title: (page.title ?? "Untitled").replace(/_/g, " "),
      thumbUrl: thumb,
      fullUrl: page.original?.source ?? thumb,
      source: "wikipedia",
    });
  }
  return hits;
}

async function searchCommons(query: string): Promise<ImageHit[]> {
  const url = new URL(wikiApi("commons.wikimedia.org"));
  url.searchParams.set("action", "query");
  url.searchParams.set("format", "json");
  url.searchParams.set("origin", "*");
  url.searchParams.set("generator", "search");
  url.searchParams.set("gsrsearch", query);
  url.searchParams.set("gsrnamespace", "6");
  url.searchParams.set("gsrlimit", "18");
  url.searchParams.set("prop", "imageinfo");
  url.searchParams.set("iiprop", "url|mime");
  url.searchParams.set("iiurlwidth", "400");

  const pages = pagesFrom(await fetchJson(url));
  const allowed = new Set(["image/jpeg", "image/png", "image/webp", "image/gif"]);
  const hits: ImageHit[] = [];
  for (const page of pages) {
    const info = page.imageinfo?.[0];
    if (!info?.thumburl && !info?.url) continue;
    if (info.mime && !allowed.has(info.mime)) continue;
    const title = (page.title ?? "Image").replace(/^File:/, "").replace(/_/g, " ");
    hits.push({
      id: `commons-${page.pageid ?? title}`,
      title: title.replace(/\.[a-z0-9]+$/i, ""),
      thumbUrl: info.thumburl ?? info.url ?? "",
      fullUrl: info.url ?? info.thumburl ?? "",
      source: "commons",
    });
  }
  return hits.filter((h) => h.thumbUrl);
}

function dedupe(hits: ImageHit[]) {
  const seen = new Set<string>();
  const out: ImageHit[] = [];
  for (const hit of hits) {
    const key = hit.thumbUrl.split("?")[0] ?? hit.thumbUrl;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(hit);
  }
  return out;
}

export async function searchImages(query: string): Promise<ImageHit[]> {
  const q = query.trim().slice(0, 80);
  if (!q) return [];

  const settled = await Promise.allSettled([
    searchWikipedia(q),
    searchCommons(q),
  ]);

  const wiki = settled[0]?.status === "fulfilled" ? settled[0].value : [];
  const commons = settled[1]?.status === "fulfilled" ? settled[1].value : [];

  if (wiki.length === 0 && commons.length === 0) {
    const failed = settled.every((s) => s.status === "rejected");
    if (failed) {
      throw new Error("Image search is unavailable right now. Try a link or upload.");
    }
  }

  return dedupe([...wiki, ...commons]).slice(0, 30);
}
