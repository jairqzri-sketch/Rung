import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import { makeTiers, type TemplateId } from "@/lib/templates";
import type { Board, Item } from "@/lib/types";
import { UNRANKED } from "@/lib/types";
import { uid } from "@/lib/utils";

const MAX_ITEMS = 160;
const MAX_TIERS = 12;

type BoardState = {
  boards: Record<string, Board>;
  createBoard: (title: string, template: TemplateId) => string;
  duplicateBoard: (id: string) => string | null;
  deleteBoard: (id: string) => void;
  importBoard: (board: Board) => string;
  setTitle: (id: string, title: string) => void;
  setTierName: (boardId: string, tierId: string, name: string) => void;
  setTierColor: (boardId: string, tierId: string, color: string) => void;
  addTier: (boardId: string) => void;
  removeTier: (boardId: string, tierId: string) => void;
  moveTier: (boardId: string, tierId: string, direction: "up" | "down") => void;
  addItem: (boardId: string, item: Omit<Item, "id">, zone?: string) => string | null;
  removeItem: (boardId: string, itemId: string) => void;
  renameItem: (boardId: string, itemId: string, label: string) => void;
  moveItem: (boardId: string, itemId: string, destZone: string, destIndex: number) => void;
  resetRanks: (boardId: string) => void;
};

function touch(board: Board): Board {
  return { ...board, updatedAt: Date.now() };
}

function patch(boards: Record<string, Board>, id: string, fn: (b: Board) => Board) {
  const current = boards[id];
  if (!current) return { boards };
  return { boards: { ...boards, [id]: touch(fn(current)) } };
}

export const useBoardStore = create<BoardState>()(
  persist(
    (set, get) => ({
      boards: {},

      createBoard: (title, template) => {
        const id = uid();
        const now = Date.now();
        const tiers = makeTiers(template);
        const placements: Record<string, string[]> = { [UNRANKED]: [] };
        for (const tier of tiers) placements[tier.id] = [];
        const board: Board = {
          id,
          title: title.trim() || "Untitled",
          createdAt: now,
          updatedAt: now,
          tiers,
          items: {},
          placements,
        };
        set((s) => ({ boards: { ...s.boards, [id]: board } }));
        return id;
      },

      duplicateBoard: (id) => {
        const source = get().boards[id];
        if (!source) return null;
        const nextId = uid();
        const now = Date.now();
        const tierIdMap = new Map<string, string>();
        const tiers = source.tiers.map((tier) => {
          const newId = uid();
          tierIdMap.set(tier.id, newId);
          return { ...tier, id: newId };
        });
        const itemIdMap = new Map<string, string>();
        const items: Record<string, Item> = {};
        for (const item of Object.values(source.items)) {
          const newId = uid();
          itemIdMap.set(item.id, newId);
          items[newId] = { ...item, id: newId };
        }
        const remap = (ids: string[]) =>
          ids.map((old) => itemIdMap.get(old)).filter((x): x is string => Boolean(x));
        const placements: Record<string, string[]> = {
          [UNRANKED]: remap(source.placements[UNRANKED] ?? []),
        };
        for (const tier of source.tiers) {
          const newTierId = tierIdMap.get(tier.id);
          if (!newTierId) continue;
          placements[newTierId] = remap(source.placements[tier.id] ?? []);
        }
        set((s) => ({
          boards: {
            ...s.boards,
            [nextId]: {
              ...source,
              id: nextId,
              title: `${source.title} copy`,
              createdAt: now,
              updatedAt: now,
              tiers,
              items,
              placements,
            },
          },
        }));
        return nextId;
      },

      deleteBoard: (id) => {
        set((s) => {
          const { [id]: _, ...rest } = s.boards;
          return { boards: rest };
        });
      },

      importBoard: (incoming) => {
        const id = uid();
        const now = Date.now();
        const board: Board = {
          ...incoming,
          id,
          createdAt: now,
          updatedAt: now,
          title: incoming.title?.trim() || "Imported",
        };
        set((s) => ({ boards: { ...s.boards, [id]: board } }));
        return id;
      },

      setTitle: (id, title) => {
        set((s) => patch(s.boards, id, (b) => ({ ...b, title: title.trim() || "Untitled" })));
      },

      setTierName: (boardId, tierId, name) => {
        set((s) =>
          patch(s.boards, boardId, (b) => ({
            ...b,
            tiers: b.tiers.map((t) => (t.id === tierId ? { ...t, name: name.slice(0, 18) } : t)),
          })),
        );
      },

      setTierColor: (boardId, tierId, color) => {
        set((s) =>
          patch(s.boards, boardId, (b) => ({
            ...b,
            tiers: b.tiers.map((t) => (t.id === tierId ? { ...t, color } : t)),
          })),
        );
      },

      addTier: (boardId) => {
        set((s) =>
          patch(s.boards, boardId, (b) => {
            if (b.tiers.length >= MAX_TIERS) return b;
            const id = uid();
            return {
              ...b,
              tiers: [...b.tiers, { id, name: "New", color: "#4a4a4e" }],
              placements: { ...b.placements, [id]: [] },
            };
          }),
        );
      },

      removeTier: (boardId, tierId) => {
        set((s) =>
          patch(s.boards, boardId, (b) => {
            if (b.tiers.length <= 1) return b;
            const moved = b.placements[tierId] ?? [];
            const { [tierId]: _, ...rest } = b.placements;
            return {
              ...b,
              tiers: b.tiers.filter((t) => t.id !== tierId),
              placements: {
                ...rest,
                [UNRANKED]: [...(rest[UNRANKED] ?? []), ...moved],
              },
            };
          }),
        );
      },

      moveTier: (boardId, tierId, direction) => {
        set((s) =>
          patch(s.boards, boardId, (b) => {
            const index = b.tiers.findIndex((t) => t.id === tierId);
            if (index < 0) return b;
            const next = [...b.tiers];
            const swap = direction === "up" ? index - 1 : index + 1;
            if (swap < 0 || swap >= next.length) return b;
            const tmp = next[index];
            next[index] = next[swap];
            next[swap] = tmp;
            return { ...b, tiers: next };
          }),
        );
      },

      addItem: (boardId, item, zone = UNRANKED) => {
        const board = get().boards[boardId];
        if (!board) return null;
        if (Object.keys(board.items).length >= MAX_ITEMS) return null;
        const id = uid();
        const dest = zone in board.placements ? zone : UNRANKED;
        set((s) =>
          patch(s.boards, boardId, (b) => ({
            ...b,
            items: { ...b.items, [id]: { ...item, id } },
            placements: {
              ...b.placements,
              [dest]: [...(b.placements[dest] ?? []), id],
            },
          })),
        );
        return id;
      },

      removeItem: (boardId, itemId) => {
        set((s) =>
          patch(s.boards, boardId, (b) => {
            const { [itemId]: _, ...items } = b.items;
            const placements = Object.fromEntries(
              Object.entries(b.placements).map(([k, ids]) => [k, ids.filter((id) => id !== itemId)]),
            );
            return { ...b, items, placements };
          }),
        );
      },

      renameItem: (boardId, itemId, label) => {
        set((s) =>
          patch(s.boards, boardId, (b) => {
            const item = b.items[itemId];
            if (!item) return b;
            return {
              ...b,
              items: { ...b.items, [itemId]: { ...item, label: label.slice(0, 48) } },
            };
          }),
        );
      },

      moveItem: (boardId, itemId, destZone, destIndex) => {
        set((s) =>
          patch(s.boards, boardId, (b) => {
            if (!b.items[itemId]) return b;
            const zone = destZone in b.placements ? destZone : UNRANKED;
            const placements: Record<string, string[]> = {};
            let fromIndex = -1;
            let fromZone = UNRANKED;
            for (const [key, ids] of Object.entries(b.placements)) {
              const next = ids.filter((id, i) => {
                if (id === itemId) {
                  fromIndex = i;
                  fromZone = key;
                  return false;
                }
                return true;
              });
              placements[key] = next;
            }
            const list = [...(placements[zone] ?? [])];
            let index = destIndex;
            if (fromZone === zone && fromIndex >= 0 && fromIndex < index) index -= 1;
            index = Math.max(0, Math.min(index, list.length));
            list.splice(index, 0, itemId);
            placements[zone] = list;
            return { ...b, placements };
          }),
        );
      },

      resetRanks: (boardId) => {
        set((s) =>
          patch(s.boards, boardId, (b) => {
            const all = Object.keys(b.items);
            const placements: Record<string, string[]> = { [UNRANKED]: all };
            for (const tier of b.tiers) placements[tier.id] = [];
            return { ...b, placements };
          }),
        );
      },
    }),
    {
      name: "rung-boards-v1",
      storage: createJSONStorage(() => {
        if (typeof window === "undefined") {
          return {
            getItem: () => null,
            setItem: () => {},
            removeItem: () => {},
          };
        }
        return localStorage;
      }),
      partialize: (s) => ({ boards: s.boards }),
      skipHydration: true,
    },
  ),
);

export function listBoards(boards: Record<string, Board>) {
  return Object.values(boards).sort((a, b) => b.updatedAt - a.updatedAt);
}
