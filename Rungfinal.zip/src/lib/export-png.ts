import { onColor } from "@/lib/colors";
import { slugify } from "@/lib/utils";
import type { Board } from "@/lib/types";

const TILE = 88;
const LABEL_W = 108;
const PAD = 18;
const GAP = 6;
const BG = "#0b0b0c";
const SURFACE = "#141416";
const FG = "#f3f1ec";
const MUTED = "#8c8a84";

function loadImage(src: string): Promise<HTMLImageElement | null> {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = src;
  });
}

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
) {
  const radius = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.arcTo(x + w, y, x + w, y + h, radius);
  ctx.arcTo(x + w, y + h, x, y + h, radius);
  ctx.arcTo(x, y + h, x, y, radius);
  ctx.arcTo(x, y, x + w, y, radius);
  ctx.closePath();
}

function drawCover(
  ctx: CanvasRenderingContext2D,
  img: HTMLImageElement,
  x: number,
  y: number,
  size: number,
) {
  const scale = Math.max(size / img.width, size / img.height);
  const w = img.width * scale;
  const h = img.height * scale;
  const dx = x + (size - w) / 2;
  const dy = y + (size - h) / 2;
  ctx.save();
  roundRect(ctx, x, y, size, size, 6);
  ctx.clip();
  ctx.drawImage(img, dx, dy, w, h);
  ctx.restore();
}

export async function exportBoardPng(board: Board) {
  const rows = board.tiers.map((tier) => ({
    tier,
    ids: board.placements[tier.id] ?? [],
  }));
  const maxItems = Math.max(1, ...rows.map((r) => r.ids.length), 4);
  const width = Math.max(720, PAD * 2 + LABEL_W + maxItems * (TILE + GAP) + GAP);
  const titleH = 72;
  const rowH = (ids: string[]) =>
    Math.max(TILE + 16, 16 + Math.ceil(Math.max(ids.length, 1) / maxItems) * (TILE + GAP));
  // Single-line rows: height is TILE + vertical padding
  const rowHeights = rows.map(() => TILE + 20);
  const height = titleH + PAD + rowHeights.reduce((a, b) => a + b, 0) + rows.length * 4;

  const uniqueUrls = [
    ...new Set(
      Object.values(board.items)
        .map((item) => item.imageUrl)
        .filter((u): u is string => Boolean(u)),
    ),
  ];
  const loaded = await Promise.all(uniqueUrls.map(async (url) => [url, await loadImage(url)] as const));
  const images = new Map(loaded);

  const canvas = document.createElement("canvas");
  const scale = 2;
  canvas.width = width * scale;
  canvas.height = height * scale;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Could not export");
  ctx.scale(scale, scale);

  ctx.fillStyle = BG;
  ctx.fillRect(0, 0, width, height);

  ctx.fillStyle = FG;
  ctx.font = '500 32px "Instrument Serif", Georgia, serif';
  ctx.fillText(board.title || "Untitled", PAD, 48);

  ctx.fillStyle = MUTED;
  ctx.font = '500 12px Figtree, system-ui, sans-serif';
  ctx.fillText("Rung", width - PAD - 40, 46);

  let y = titleH;
  for (const row of rows) {
    const h = TILE + 20;
    ctx.fillStyle = SURFACE;
    roundRect(ctx, PAD, y, width - PAD * 2, h, 10);
    ctx.fill();

    ctx.fillStyle = row.tier.color;
    roundRect(ctx, PAD, y, LABEL_W, h, 10);
    ctx.fill();
    // square off the right of the label so it meets the row
    ctx.fillRect(PAD + LABEL_W - 10, y, 10, h);

    ctx.fillStyle = onColor(row.tier.color);
    ctx.font = '600 20px Figtree, system-ui, sans-serif';
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(row.tier.name.slice(0, 12), PAD + LABEL_W / 2, y + h / 2, LABEL_W - 12);
    ctx.textAlign = "left";
    ctx.textBaseline = "alphabetic";

    let x = PAD + LABEL_W + GAP + 4;
    for (const id of row.ids) {
      const item = board.items[id];
      if (!item) continue;
      const img = item.imageUrl ? images.get(item.imageUrl) : null;
      if (img) {
        drawCover(ctx, img, x, y + 10, TILE);
      } else {
        ctx.fillStyle = "#1c1c1f";
        roundRect(ctx, x, y + 10, TILE, TILE, 6);
        ctx.fill();
        ctx.fillStyle = FG;
        ctx.font = '600 11px Figtree, system-ui, sans-serif';
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        const label = item.label || "?";
        ctx.fillText(label.slice(0, 10), x + TILE / 2, y + 10 + TILE / 2, TILE - 8);
        ctx.textAlign = "left";
        ctx.textBaseline = "alphabetic";
      }
      x += TILE + GAP;
      if (x > width - PAD - TILE) break;
    }
    y += h + 4;
  }

  return new Promise<void>((resolve, reject) => {
    canvas.toBlob((blob) => {
      if (!blob) {
        reject(new Error("Could not export this list. Try again without hotlinked images."));
        return;
      }
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = `${slugify(board.title)}.png`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 4_000);
      resolve();
    }, "image/png");
  });
}

export function exportBoardJson(board: Board) {
  const blob = new Blob([JSON.stringify(board, null, 2)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `${slugify(board.title)}.json`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 4_000);
}
