import { uid } from "@/lib/utils";
import type { Tier } from "@/lib/types";

export type TemplateId = "classic" | "five" | "verdict" | "blank";

export type Template = {
  id: TemplateId;
  name: string;
  hint: string;
  tiers: { name: string; color: string }[];
};

export const TEMPLATES: Template[] = [
  {
    id: "classic",
    name: "Classic",
    hint: "S through F",
    tiers: [
      { name: "S", color: "#e85d4c" },
      { name: "A", color: "#e89a4c" },
      { name: "B", color: "#e8c84c" },
      { name: "C", color: "#7dbe6a" },
      { name: "D", color: "#5aa0d6" },
      { name: "F", color: "#8b86a8" },
    ],
  },
  {
    id: "five",
    name: "Five rungs",
    hint: "Loved to no",
    tiers: [
      { name: "Loved", color: "#e85d4c" },
      { name: "Liked", color: "#e89a4c" },
      { name: "Fine", color: "#e8c84c" },
      { name: "Meh", color: "#5aa0d6" },
      { name: "No", color: "#8b86a8" },
    ],
  },
  {
    id: "verdict",
    name: "Verdict",
    hint: "Keep, maybe, pass",
    tiers: [
      { name: "Keep", color: "#2f9e7b" },
      { name: "Maybe", color: "#e8c84c" },
      { name: "Pass", color: "#8b86a8" },
    ],
  },
  {
    id: "blank",
    name: "Blank",
    hint: "One empty rung",
    tiers: [{ name: "New", color: "#4a4a4e" }],
  },
];

export function makeTiers(templateId: TemplateId = "classic"): Tier[] {
  const template = TEMPLATES.find((t) => t.id === templateId) ?? TEMPLATES[0];
  return template.tiers.map((tier) => ({
    id: uid(),
    name: tier.name,
    color: tier.color,
  }));
}
