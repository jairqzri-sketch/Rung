import { TIER_SWATCHES } from "@/lib/colors";
import { cn } from "@/lib/utils";

type Props = {
  value: string;
  onChange: (color: string) => void;
};

export function ColorField({ value, onChange }: Props) {
  return (
    <div className="flex flex-col gap-2">
      <div className="flex flex-wrap gap-1.5">
        {TIER_SWATCHES.map((color) => (
          <button
            key={color}
            type="button"
            aria-label={`Use ${color}`}
            onClick={() => onChange(color)}
            className={cn(
              "size-7 rounded-xs transition-[transform,box-shadow] duration-150 ease-out",
              value.toLowerCase() === color.toLowerCase()
                ? "scale-95 shadow-[0_0_0_2px_var(--color-bg),0_0_0_4px_var(--color-accent)]"
                : "shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
            )}
            style={{ backgroundColor: color }}
          />
        ))}
      </div>
      <label className="flex h-11 items-center gap-2 rounded-sm bg-surface-2 px-2 shadow-[var(--shadow-border)]">
        <input
          type="color"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="size-7 cursor-pointer rounded-xs bg-transparent"
          aria-label="Custom color"
        />
        <input
          value={value}
          onChange={(e) => {
            const next = e.target.value.trim();
            if (/^#?[0-9a-fA-F]{0,6}$/.test(next)) {
              onChange(next.startsWith("#") ? next : `#${next}`);
            }
          }}
          className="min-w-0 flex-1 bg-transparent font-mono text-sm text-fg outline-none"
          spellCheck={false}
        />
      </label>
    </div>
  );
}
