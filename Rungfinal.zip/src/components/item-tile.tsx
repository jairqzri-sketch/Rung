import { X } from "lucide-react";
import type { PointerEvent as ReactPointerEvent } from "react";
import type { Item } from "@/lib/types";
import { cn } from "@/lib/utils";

type Props = {
  item: Item;
  selected?: boolean;
  dimmed?: boolean;
  onPointerDown: (event: ReactPointerEvent<HTMLButtonElement>) => void;
  onRemove?: () => void;
};

export function ItemTile({ item, selected, dimmed, onPointerDown, onRemove }: Props) {
  return (
    <div
      className={cn(
        "group relative size-16 shrink-0 touch-manipulation md:size-20",
        dimmed && "opacity-40",
      )}
      data-item-id={item.id}
    >
      <button
        type="button"
        onPointerDown={(event) => {
          event.stopPropagation();
          onPointerDown(event);
        }}
        onClick={(event) => event.stopPropagation()}
        aria-pressed={selected}
        aria-label={item.label || "Item"}
        className={cn(
          "size-full overflow-hidden rounded-xs bg-surface-2 text-left shadow-[var(--shadow-border)]",
          "transition-[box-shadow,transform] duration-150 ease-out",
          selected && "shadow-[0_0_0_2px_var(--color-bg),0_0_0_4px_var(--color-accent)]",
        )}
      >
        {item.imageUrl ? (
          <img
            src={item.imageUrl}
            alt=""
            draggable={false}
            className="size-full object-cover outline outline-1 -outline-offset-1 outline-fg/10"
          />
        ) : (
          <span className="flex size-full items-center justify-center px-1 text-center text-xs leading-tight font-medium text-fg">
            {item.label || "Item"}
          </span>
        )}
      </button>
      {item.imageUrl && item.label ? (
        <span className="pointer-events-none absolute inset-x-0 bottom-0 truncate bg-bg/70 px-1 py-0.5 text-xs text-fg opacity-0 transition-opacity duration-150 group-hover:opacity-100">
          {item.label}
        </span>
      ) : null}
      {onRemove ? (
        <button
          type="button"
          aria-label={`Remove ${item.label || "item"}`}
          onClick={(e) => {
            e.stopPropagation();
            onRemove();
          }}
          className="absolute -top-1.5 -right-1.5 z-10 hidden size-6 items-center justify-center rounded-full bg-surface-2 text-fg shadow-[var(--shadow-border)] group-hover:flex group-focus-within:flex"
        >
          <X className="size-3" />
        </button>
      ) : null}
    </div>
  );
}
