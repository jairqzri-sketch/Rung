import { Toaster as Sonner } from "sonner";

export function Toaster() {
  return (
    <Sonner
      theme="dark"
      position="bottom-center"
      toastOptions={{
        className: "bg-surface-2 text-fg shadow-[var(--shadow-border)]",
      }}
    />
  );
}
