import { useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { TEMPLATES, type TemplateId } from "@/lib/templates";
import { useBoardStore } from "@/lib/store";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
};

export function NewBoardDialog({ open, onOpenChange }: Props) {
  const navigate = useNavigate();
  const createBoard = useBoardStore((s) => s.createBoard);
  const [title, setTitle] = useState("");
  const [template, setTemplate] = useState<TemplateId>("classic");

  function handleCreate() {
    const id = createBoard(title || "Untitled", template);
    setTitle("");
    setTemplate("classic");
    onOpenChange(false);
    void navigate({ to: "/b/$boardId", params: { boardId: id } });
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>New list</DialogTitle>
          <DialogDescription>Pick a starting set of rungs. You can rename and recolor every one.</DialogDescription>
        </DialogHeader>
        <label className="mb-3 block text-sm font-medium text-muted">
          Name
          <Input
            className="mt-1.5"
            value={title}
            placeholder="Weekend movies"
            onChange={(e) => setTitle(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") handleCreate();
            }}
            autoFocus
          />
        </label>
        <p className="mb-2 text-sm font-medium text-muted">Rungs</p>
        <div className="grid grid-cols-2 gap-2">
          {TEMPLATES.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setTemplate(item.id)}
              className={cn(
                "rounded-md bg-surface-2 p-3 text-left transition-[box-shadow,transform] duration-150 ease-out",
                template === item.id
                  ? "shadow-[0_0_0_1px_var(--color-accent)]"
                  : "shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
              )}
            >
              <div className="mb-2 flex h-2 overflow-hidden rounded-xs">
                {item.tiers.map((tier) => (
                  <span key={tier.name} className="flex-1" style={{ backgroundColor: tier.color }} />
                ))}
              </div>
              <div className="text-sm font-medium text-fg">{item.name}</div>
              <div className="text-xs text-muted">{item.hint}</div>
            </button>
          ))}
        </div>
        <Button className="mt-4 w-full" onClick={handleCreate}>
          Create list
        </Button>
      </DialogContent>
    </Dialog>
  );
}
