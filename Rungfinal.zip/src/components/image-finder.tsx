import { useRef, useState, type FormEvent } from "react";
import { ImagePlus, Link2, Search, Type, Upload } from "lucide-react";
import { toast } from "sonner";
import { searchImages, type ImageHit } from "@/lib/search-images";
import { looksLikeImageUrl, resizeImageFile } from "@/lib/resize-image";
import { useBoardStore } from "@/lib/store";
import type { Board } from "@/lib/types";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

type Tab = "search" | "upload" | "link" | "text";

type Props = {
  board: Board;
  className?: string;
};

export function ImageFinder({ board, className }: Props) {
  const addItem = useBoardStore((s) => s.addItem);
  const fileRef = useRef<HTMLInputElement>(null);
  const [tab, setTab] = useState<Tab>("search");
  const [query, setQuery] = useState("");
  const [hits, setHits] = useState<ImageHit[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [link, setLink] = useState("");
  const [label, setLabel] = useState("");

  const existing = new Set(
    Object.values(board.items)
      .map((item) => item.imageUrl)
      .filter(Boolean),
  );

  function pushItem(item: { label: string; imageUrl: string | null; sourceUrl?: string }) {
    if (item.imageUrl && existing.has(item.imageUrl)) {
      toast("Already on the board");
      return;
    }
    const id = addItem(board.id, item);
    if (!id) {
      toast.error("This list is full (160 items).");
      return;
    }
    toast.success("Added to unranked");
  }

  async function onSearch(event?: FormEvent) {
    event?.preventDefault();
    const q = query.trim();
    if (!q) return;
    setBusy(true);
    setError(null);
    try {
      const results = await searchImages(q);
      setHits(results);
      if (results.length === 0) setError("No images found. Try a simpler name.");
    } catch (err) {
      setHits([]);
      setError(err instanceof Error ? err.message : "Search failed");
    } finally {
      setBusy(false);
    }
  }

  async function onFiles(files: FileList | null) {
    if (!files?.length) return;
    for (const file of [...files].slice(0, 24)) {
      if (!file.type.startsWith("image/")) continue;
      try {
        const dataUrl = await resizeImageFile(file);
        pushItem({
          label: file.name.replace(/\.[^.]+$/, ""),
          imageUrl: dataUrl,
        });
      } catch {
        toast.error(`Could not read ${file.name}`);
      }
    }
  }

  function onAddLink() {
    const url = link.trim();
    if (!looksLikeImageUrl(url)) {
      toast.error("Use a full http(s) image link");
      return;
    }
    pushItem({ label: "Image", imageUrl: url, sourceUrl: url });
    setLink("");
  }

  function onAddText() {
    const text = label.trim();
    if (!text) return;
    pushItem({ label: text, imageUrl: null });
    setLabel("");
  }

  const tabs: { id: Tab; icon: typeof Search; label: string }[] = [
    { id: "search", icon: Search, label: "Search" },
    { id: "upload", icon: Upload, label: "Upload" },
    { id: "link", icon: Link2, label: "Link" },
    { id: "text", icon: Type, label: "Text" },
  ];

  return (
    <div className={cn("flex h-full min-h-0 flex-col", className)}>
      <div className="flex gap-1 p-1">
        {tabs.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setTab(item.id)}
            className={cn(
              "flex h-10 flex-1 items-center justify-center gap-1.5 rounded-xs text-xs font-medium transition-colors duration-150",
              tab === item.id ? "bg-surface-2 text-fg" : "text-muted hover:text-fg",
            )}
          >
            <item.icon className="size-3.5" />
            <span className="hidden sm:inline">{item.label}</span>
          </button>
        ))}
      </div>

      {tab === "search" ? (
        <form onSubmit={onSearch} className="flex gap-2 px-3 pb-3">
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Pizza, Ghibli, sneakers…"
            aria-label="Search images"
          />
          <Button type="submit" disabled={busy || !query.trim()} className="shrink-0">
            {busy ? "…" : "Find"}
          </Button>
        </form>
      ) : null}

      {tab === "upload" ? (
        <div className="px-3 pb-3">
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            multiple
            className="hidden"
            onChange={(e) => {
              void onFiles(e.target.files);
              e.target.value = "";
            }}
          />
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            className="flex h-28 w-full flex-col items-center justify-center gap-2 rounded-md bg-surface-2 text-sm text-muted shadow-[var(--shadow-border)] transition-colors duration-150 hover:text-fg"
          >
            <ImagePlus className="size-5" />
            Drop or choose images
          </button>
        </div>
      ) : null}

      {tab === "link" ? (
        <div className="flex gap-2 px-3 pb-3">
          <Input
            value={link}
            onChange={(e) => setLink(e.target.value)}
            placeholder="https://…"
            onKeyDown={(e) => {
              if (e.key === "Enter") onAddLink();
            }}
          />
          <Button type="button" onClick={onAddLink} className="shrink-0">
            Add
          </Button>
        </div>
      ) : null}

      {tab === "text" ? (
        <div className="flex gap-2 px-3 pb-3">
          <Input
            value={label}
            onChange={(e) => setLabel(e.target.value)}
            placeholder="A name, no picture"
            onKeyDown={(e) => {
              if (e.key === "Enter") onAddText();
            }}
          />
          <Button type="button" onClick={onAddText} className="shrink-0">
            Add
          </Button>
        </div>
      ) : null}

      <div
        className="min-h-0 flex-1 overflow-y-auto px-3 pb-4"
        onDragOver={(e) => {
          if ([...e.dataTransfer.types].includes("Files")) e.preventDefault();
        }}
        onDrop={(e) => {
          if (e.dataTransfer.files.length) {
            e.preventDefault();
            void onFiles(e.dataTransfer.files);
          }
        }}
      >
        {tab === "search" && error ? <p className="mb-3 text-sm text-muted">{error}</p> : null}
        {tab === "search" && hits.length > 0 ? (
          <div className="grid grid-cols-3 gap-2">
            {hits.map((hit) => {
              const added = existing.has(hit.thumbUrl) || existing.has(hit.fullUrl);
              return (
                <button
                  key={hit.id}
                  type="button"
                  disabled={added}
                  onClick={() =>
                    pushItem({
                      label: hit.title,
                      imageUrl: hit.thumbUrl,
                      sourceUrl: hit.fullUrl,
                    })
                  }
                  aria-label={added ? `${hit.title} (added)` : `Add ${hit.title}`}
                  className="group relative aspect-square overflow-hidden rounded-xs bg-surface-2 shadow-[var(--shadow-border)] disabled:opacity-50"
                  title={hit.title}
                >
                  <img
                    src={hit.thumbUrl}
                    alt=""
                    className="size-full object-cover outline outline-1 -outline-offset-1 outline-fg/10 transition-transform duration-200 ease-out group-hover:scale-105"
                  />
                  <span className="pointer-events-none absolute inset-x-0 bottom-0 truncate bg-bg/70 px-1 py-0.5 text-left text-xs text-fg">
                    {added ? "Added" : hit.title}
                  </span>
                </button>
              );
            })}
          </div>
        ) : null}
        {tab === "search" && !busy && hits.length === 0 && !error ? (
          <p className="text-sm text-muted">
            Search Wikipedia and Wikimedia Commons for pictures. Click a result to drop it into Unranked.
          </p>
        ) : null}
        {tab === "upload" ? (
          <p className="text-sm text-muted">Images are resized and stored in this browser.</p>
        ) : null}
      </div>
    </div>
  );
}
