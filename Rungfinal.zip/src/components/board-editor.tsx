import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type PointerEvent as ReactPointerEvent,
  type ReactNode,
} from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import {
  ArrowDown,
  ArrowLeft,
  ArrowUp,
  Check,
  Download,
  ImagePlus,
  MoreHorizontal,
  Plus,
  RotateCcw,
  Trash2,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { onColor } from "@/lib/colors";
import { exportBoardJson, exportBoardPng } from "@/lib/export-png";
import { resizeImageFile } from "@/lib/resize-image";
import { useBoardStore } from "@/lib/store";
import type { Board, Item } from "@/lib/types";
import { UNRANKED } from "@/lib/types";
import { cn } from "@/lib/utils";
import { ColorField } from "@/components/color-field";
import { ImageFinder } from "@/components/image-finder";
import { ItemTile } from "@/components/item-tile";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";

type Over = { zone: string; index: number } | null;

type Ghost = {
  item: Item;
  x: number;
  y: number;
  w: number;
  h: number;
  ox: number;
  oy: number;
};

function findDrop(clientX: number, clientY: number): Over {
  const stack = document.elementsFromPoint(clientX, clientY);
  for (const el of stack) {
    if (!(el instanceof HTMLElement)) continue;
    const itemId = el.closest("[data-item-id]")?.getAttribute("data-item-id");
    const zoneEl = el.closest("[data-drop-zone]");
    if (!zoneEl) continue;
    const zone = zoneEl.getAttribute("data-drop-zone");
    if (!zone) continue;
    if (itemId) {
      const row = [...zoneEl.querySelectorAll("[data-item-id]")];
      const index = row.findIndex((n) => n.getAttribute("data-item-id") === itemId);
      return { zone, index: index < 0 ? row.length : index };
    }
    return { zone, index: zoneEl.querySelectorAll("[data-item-id]").length };
  }
  return null;
}

function ZoneRow({
  zone,
  label,
  color,
  ids,
  items,
  selectedId,
  draggingId,
  over,
  onPointerDown,
  onRemove,
  onPlace,
  onName,
  onEdit,
  trailing,
}: {
  zone: string;
  label: string;
  color?: string;
  ids: string[];
  items: Record<string, Item>;
  selectedId: string | null;
  draggingId: string | null;
  over: Over;
  onPointerDown: (event: ReactPointerEvent<HTMLButtonElement>, itemId: string) => void;
  onRemove: (itemId: string) => void;
  onPlace: () => void;
  onName?: (name: string) => void;
  onEdit?: () => void;
  trailing?: ReactNode;
}) {
  const isOver = over?.zone === zone;

  return (
    <div className="flex min-h-20 overflow-hidden rounded-md bg-surface shadow-[var(--shadow-border)] md:min-h-24">
      <div
        className="flex w-16 shrink-0 flex-col md:w-24"
        style={color ? { backgroundColor: color, color: onColor(color) } : undefined}
      >
        {onName ? (
          <input
            value={label}
            maxLength={18}
            aria-label="Tier name"
            onChange={(e) => onName(e.target.value)}
            className="h-full w-full bg-transparent px-1.5 text-center text-sm font-semibold tracking-tight outline-none md:text-base"
            style={{ color: color ? onColor(color) : undefined }}
          />
        ) : (
          <div className="flex h-full items-center justify-center px-2 text-center text-xs font-medium tracking-wide text-muted uppercase">
            {label}
          </div>
        )}
      </div>
      <div
        data-drop-zone={zone}
        onClick={() => {
          if (selectedId) onPlace();
        }}
        className={cn(
          "flex min-h-20 min-w-0 flex-1 flex-wrap content-start items-start gap-2 p-2 md:min-h-24",
          isOver && "bg-surface-2",
          selectedId && "cursor-copy",
        )}
      >
        {ids.map((id, index) => {
          const item = items[id];
          if (!item) return null;
          return (
            <div key={id} className="relative">
              {isOver && over.index === index ? (
                <span className="absolute top-0 -left-1.5 h-16 w-0.5 rounded-full bg-accent md:h-20" />
              ) : null}
              <ItemTile
                item={item}
                selected={selectedId === id}
                dimmed={draggingId === id}
                onPointerDown={(e) => onPointerDown(e, id)}
                onRemove={() => onRemove(id)}
              />
            </div>
          );
        })}
        {isOver && over.index >= ids.length ? (
          <span className="h-16 w-0.5 rounded-full bg-accent md:h-20" />
        ) : null}
        {ids.length === 0 && !isOver ? (
          <span className="self-center px-1 text-xs text-subtle">
            {selectedId ? "Tap to place" : "Drop here"}
          </span>
        ) : null}
      </div>
      {onEdit || trailing ? (
        <div className="flex shrink-0 flex-col justify-center gap-0.5 border-l border-border p-1">
          {onEdit ? (
            <button
              type="button"
              onClick={onEdit}
              className="inline-flex size-8 items-center justify-center rounded-xs text-muted hover:bg-surface-2 hover:text-fg"
              aria-label={`Customize ${label}`}
            >
              <MoreHorizontal className="size-4" />
            </button>
          ) : null}
          {trailing}
        </div>
      ) : null}
    </div>
  );
}

export function BoardEditor({ board }: { board: Board }) {
  const setTitle = useBoardStore((s) => s.setTitle);
  const setTierName = useBoardStore((s) => s.setTierName);
  const setTierColor = useBoardStore((s) => s.setTierColor);
  const addTier = useBoardStore((s) => s.addTier);
  const removeTier = useBoardStore((s) => s.removeTier);
  const moveTier = useBoardStore((s) => s.moveTier);
  const moveItem = useBoardStore((s) => s.moveItem);
  const removeItem = useBoardStore((s) => s.removeItem);
  const resetRanks = useBoardStore((s) => s.resetRanks);
  const deleteBoard = useBoardStore((s) => s.deleteBoard);
  const addItem = useBoardStore((s) => s.addItem);
  const navigate = useNavigate();

  const [title, setTitleLocal] = useState(board.title);
  const [finderOpen, setFinderOpen] = useState(false);
  const [editingTier, setEditingTier] = useState<string | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [draggingId, setDraggingId] = useState<string | null>(null);
  const [over, setOver] = useState<Over>(null);
  const [ghost, setGhost] = useState<Ghost | null>(null);
  const dragRef = useRef<{
    itemId: string;
    pointerId: number;
    startX: number;
    startY: number;
    active: boolean;
    ox: number;
    oy: number;
    w: number;
    h: number;
  } | null>(null);

  useEffect(() => {
    setTitleLocal(board.title);
  }, [board.title]);

  useEffect(() => {
    if (window.matchMedia("(min-width: 768px)").matches) setFinderOpen(true);
  }, []);

  useEffect(() => {
    const onPaste = (event: ClipboardEvent) => {
      const files = [...(event.clipboardData?.files ?? [])].filter((file) =>
        file.type.startsWith("image/"),
      );
      if (files.length === 0) return;
      event.preventDefault();
      void (async () => {
        for (const file of files) {
          try {
            const dataUrl = await resizeImageFile(file);
            addItem(board.id, {
              label: file.name.replace(/\.[^.]+$/, "") || "Pasted",
              imageUrl: dataUrl,
            });
          } catch {
            toast.error("Could not paste that image");
          }
        }
      })();
    };
    window.addEventListener("paste", onPaste);
    return () => window.removeEventListener("paste", onPaste);
  }, [addItem, board.id]);

  const editing = board.tiers.find((t) => t.id === editingTier) ?? null;

  const placeSelected = useCallback(
    (zone: string, index: number) => {
      if (!selectedId) return;
      moveItem(board.id, selectedId, zone, index);
      setSelectedId(null);
    },
    [board.id, moveItem, selectedId],
  );

  const onPointerDown = useCallback(
    (event: ReactPointerEvent<HTMLButtonElement>, itemId: string) => {
      if (event.button !== 0) return;
      const rect = event.currentTarget.getBoundingClientRect();
      dragRef.current = {
        itemId,
        pointerId: event.pointerId,
        startX: event.clientX,
        startY: event.clientY,
        active: false,
        ox: event.clientX - rect.left,
        oy: event.clientY - rect.top,
        w: rect.width,
        h: rect.height,
      };

      const onMove = (ev: PointerEvent) => {
        const drag = dragRef.current;
        if (!drag || ev.pointerId !== drag.pointerId) return;
        const dx = ev.clientX - drag.startX;
        const dy = ev.clientY - drag.startY;
        if (!drag.active && Math.hypot(dx, dy) > 16) {
          drag.active = true;
          setDraggingId(drag.itemId);
          setSelectedId(null);
          const item = board.items[drag.itemId];
          if (item) {
            setGhost({
              item,
              x: ev.clientX,
              y: ev.clientY,
              w: drag.w,
              h: drag.h,
              ox: drag.ox,
              oy: drag.oy,
            });
          }
        }
        if (drag.active) {
          ev.preventDefault();
          setGhost((g) => (g ? { ...g, x: ev.clientX, y: ev.clientY } : g));
          setOver(findDrop(ev.clientX, ev.clientY));
        }
      };

      const onUp = (ev: PointerEvent) => {
        const drag = dragRef.current;
        window.removeEventListener("pointermove", onMove);
        window.removeEventListener("pointerup", onUp);
        window.removeEventListener("pointercancel", onUp);
        dragRef.current = null;
        if (!drag || ev.pointerId !== drag.pointerId) return;
        if (drag.active) {
          const dest = findDrop(ev.clientX, ev.clientY);
          const dist = Math.hypot(ev.clientX - drag.startX, ev.clientY - drag.startY);
          if (dest && dist > 16) {
            moveItem(board.id, drag.itemId, dest.zone, dest.index);
          } else {
            setSelectedId((cur) => (cur === drag.itemId ? null : drag.itemId));
          }
          setDraggingId(null);
          setGhost(null);
          setOver(null);
        } else {
          setSelectedId((cur) => (cur === drag.itemId ? null : drag.itemId));
        }
      };

      window.addEventListener("pointermove", onMove, { passive: false });
      window.addEventListener("pointerup", onUp);
      window.addEventListener("pointercancel", onUp);
    },
    [board.id, board.items, moveItem],
  );

  async function handleExportPng() {
    try {
      await exportBoardPng(board);
      toast.success("Saved PNG");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Export failed");
    }
  }

  const unranked = board.placements[UNRANKED] ?? [];

  return (
    <div className="flex min-h-dvh flex-col bg-bg text-fg">
      <header className="flex h-14 shrink-0 items-center gap-2 border-b border-border px-3 md:px-5">
        <Button asChild variant="ghost" size="icon-sm" aria-label="Back">
          <Link to="/">
            <ArrowLeft className="size-4" />
          </Link>
        </Button>
        <input
          value={title}
          onChange={(e) => setTitleLocal(e.target.value)}
          onBlur={() => setTitle(board.id, title)}
          onKeyDown={(e) => {
            if (e.key === "Enter") (e.target as HTMLInputElement).blur();
          }}
          className="min-w-0 flex-1 bg-transparent font-serif text-xl tracking-tight outline-none md:text-2xl"
          aria-label="List title"
        />
        <Button
          variant="secondary"
          size="sm"
          className="md:hidden"
          onClick={() => setFinderOpen(true)}
        >
          <ImagePlus className="size-4" />
          Images
        </Button>
        <Button
          variant="secondary"
          size="sm"
          className="hidden md:inline-flex"
          onClick={() => setFinderOpen((v) => !v)}
        >
          <ImagePlus className="size-4" />
          {finderOpen ? "Hide" : "Images"}
        </Button>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon-sm" aria-label="List menu">
              <MoreHorizontal className="size-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onSelect={() => void handleExportPng()}>
              <Download className="size-4" />
              Download PNG
            </DropdownMenuItem>
            <DropdownMenuItem onSelect={() => exportBoardJson(board)}>
              <Download className="size-4" />
              Export JSON
            </DropdownMenuItem>
            <DropdownMenuItem onSelect={() => resetRanks(board.id)}>
              <RotateCcw className="size-4" />
              Reset to unranked
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              className="text-danger"
              onSelect={() => {
                if (window.confirm("Delete this list? This cannot be undone.")) {
                  deleteBoard(board.id);
                  void navigate({ to: "/" });
                }
              }}
            >
              <Trash2 className="size-4" />
              Delete list
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </header>

      <div className="flex min-h-0 flex-1">
        <div
          className="flex min-w-0 flex-1 flex-col"
          onDragOver={(e) => {
            if ([...e.dataTransfer.types].includes("Files")) e.preventDefault();
          }}
          onDrop={(e) => {
            const files = e.dataTransfer.files;
            if (!files.length) return;
            e.preventDefault();
            void (async () => {
              for (const file of [...files].slice(0, 24)) {
                if (!file.type.startsWith("image/")) continue;
                try {
                  const dataUrl = await resizeImageFile(file);
                  addItem(board.id, {
                    label: file.name.replace(/\.[^.]+$/, ""),
                    imageUrl: dataUrl,
                  });
                } catch {
                  toast.error(`Could not read ${file.name}`);
                }
              }
            })();
          }}
        >
          <div className="min-h-0 flex-1 space-y-1.5 overflow-y-auto p-3 md:p-5">
            {board.tiers.map((tier, index) => (
              <ZoneRow
                key={tier.id}
                zone={tier.id}
                label={tier.name}
                color={tier.color}
                ids={board.placements[tier.id] ?? []}
                items={board.items}
                selectedId={selectedId}
                draggingId={draggingId}
                over={over}
                onPointerDown={onPointerDown}
                onRemove={(id) => removeItem(board.id, id)}
                onPlace={() => placeSelected(tier.id, (board.placements[tier.id] ?? []).length)}
                onName={(name) => setTierName(board.id, tier.id, name)}
                onEdit={() => setEditingTier(tier.id)}
                trailing={
                  <>
                    <button
                      type="button"
                      disabled={index === 0}
                      onClick={() => moveTier(board.id, tier.id, "up")}
                      className="inline-flex size-8 items-center justify-center rounded-xs text-muted hover:bg-surface-2 hover:text-fg disabled:opacity-30"
                      aria-label="Move rung up"
                    >
                      <ArrowUp className="size-3.5" />
                    </button>
                    <button
                      type="button"
                      disabled={index === board.tiers.length - 1}
                      onClick={() => moveTier(board.id, tier.id, "down")}
                      className="inline-flex size-8 items-center justify-center rounded-xs text-muted hover:bg-surface-2 hover:text-fg disabled:opacity-30"
                      aria-label="Move rung down"
                    >
                      <ArrowDown className="size-3.5" />
                    </button>
                  </>
                }
              />
            ))}
            <Button
              variant="ghost"
              className="w-full text-muted"
              onClick={() => {
                if (board.tiers.length >= 12) {
                  toast.error("12 rungs is the maximum");
                  return;
                }
                addTier(board.id);
              }}
            >
              <Plus className="size-4" />
              Add rung
            </Button>
          </div>

          <div className="border-t border-border bg-bg p-3 md:px-5 md:pb-4">
            <ZoneRow
              zone={UNRANKED}
              label="Unranked"
              ids={unranked}
              items={board.items}
              selectedId={selectedId}
              draggingId={draggingId}
              over={over}
              onPointerDown={onPointerDown}
              onRemove={(id) => removeItem(board.id, id)}
              onPlace={() => placeSelected(UNRANKED, unranked.length)}
            />
            <p className="mt-2 hidden text-xs text-subtle md:block">
              Drag tiles onto a rung, or tap a tile then tap a row. Search the web from the images panel.
            </p>
          </div>
        </div>

        <aside
          className={cn(
            "hidden w-80 shrink-0 flex-col border-l border-border bg-surface md:flex",
            finderOpen ? "md:flex" : "md:hidden",
          )}
        >
          <div className="flex h-12 items-center justify-between border-b border-border px-3">
            <p className="text-sm font-medium">Find images</p>
            <button
              type="button"
              onClick={() => setFinderOpen(false)}
              className="inline-flex size-8 items-center justify-center rounded-xs text-muted hover:bg-surface-2 hover:text-fg"
              aria-label="Close images"
            >
              <X className="size-4" />
            </button>
          </div>
          <ImageFinder board={board} className="min-h-0 flex-1" />
        </aside>
      </div>

      {finderOpen ? (
        <div className="fixed inset-0 z-40 flex flex-col bg-bg md:hidden">
          <div className="flex h-14 items-center justify-between border-b border-border px-3">
            <p className="font-medium">Find images</p>
            <Button variant="ghost" size="icon-sm" onClick={() => setFinderOpen(false)} aria-label="Close">
              <X className="size-4" />
            </Button>
          </div>
          <ImageFinder board={board} className="min-h-0 flex-1" />
        </div>
      ) : null}

      {editing ? (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-bg/80 p-3 sm:items-center">
          <div className="w-full max-w-sm rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
            <div className="mb-4 flex items-start justify-between gap-3">
              <div>
                <h2 className="font-serif text-2xl tracking-tight">Rung</h2>
                <p className="text-sm text-muted">Name and color this row.</p>
              </div>
              <button
                type="button"
                onClick={() => setEditingTier(null)}
                className="inline-flex size-9 items-center justify-center rounded-sm text-muted hover:bg-surface-2 hover:text-fg"
                aria-label="Close"
              >
                <X className="size-4" />
              </button>
            </div>
            <label className="mb-3 block text-sm font-medium text-muted">
              Name
              <Input
                className="mt-1.5"
                value={editing.name}
                maxLength={18}
                onChange={(e) => setTierName(board.id, editing.id, e.target.value)}
              />
            </label>
            <p className="mb-1.5 text-sm font-medium text-muted">Color</p>
            <ColorField
              value={editing.color}
              onChange={(color) => setTierColor(board.id, editing.id, color)}
            />
            <div className="mt-4 flex gap-2">
              <Button
                variant="danger"
                className="flex-1"
                disabled={board.tiers.length <= 1}
                onClick={() => {
                  removeTier(board.id, editing.id);
                  setEditingTier(null);
                }}
              >
                <Trash2 className="size-4" />
                Remove
              </Button>
              <Button className="flex-1" onClick={() => setEditingTier(null)}>
                <Check className="size-4" />
                Done
              </Button>
            </div>
          </div>
        </div>
      ) : null}

      {ghost ? (
        <div
          className="pointer-events-none fixed z-50 overflow-hidden rounded-xs shadow-[var(--shadow-border)]"
          style={{
            width: ghost.w,
            height: ghost.h,
            left: ghost.x - ghost.ox,
            top: ghost.y - ghost.oy,
          }}
        >
          {ghost.item.imageUrl ? (
            <img src={ghost.item.imageUrl} alt="" className="size-full object-cover" />
          ) : (
            <div className="flex size-full items-center justify-center bg-surface-2 px-1 text-center text-xs font-medium">
              {ghost.item.label}
            </div>
          )}
        </div>
      ) : null}
    </div>
  );
}
