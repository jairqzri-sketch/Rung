import { useRef, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { Copy, MoreHorizontal, Plus, Trash2, Upload } from "lucide-react";
import { toast } from "sonner";
import { useHydrated } from "@/hooks/use-hydrated";
import { listBoards, useBoardStore } from "@/lib/store";
import type { Board } from "@/lib/types";
import { formatUpdated } from "@/lib/utils";
import { NewBoardDialog } from "@/components/new-board-dialog";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

function MiniRungs({ board }: { board: Board }) {
  return (
    <div className="flex flex-col gap-1">
      {board.tiers.slice(0, 6).map((tier) => (
        <div key={tier.id} className="flex h-2 overflow-hidden rounded-xs">
          <span className="w-8 shrink-0" style={{ backgroundColor: tier.color }} />
          <span className="flex-1 bg-surface-2" />
        </div>
      ))}
    </div>
  );
}

function HeroRungs() {
  const rows = [
    { name: "S", color: "#e85d4c", chips: ["#d8d2c6", "#8c8a84", "#f3f1ec"] },
    { name: "A", color: "#e89a4c", chips: ["#cfc8bb", "#6b6964"] },
    { name: "B", color: "#e8c84c", chips: ["#8c8a84", "#d8d2c6", "#6b6964", "#cfc8bb"] },
    { name: "C", color: "#7dbe6a", chips: ["#6b6964"] },
    { name: "D", color: "#5aa0d6", chips: ["#d8d2c6", "#8c8a84"] },
  ];
  return (
    <div className="flex flex-col gap-1.5 rounded-xl bg-surface p-3 shadow-[var(--shadow-border)]">
      {rows.map((row) => (
        <div key={row.name} className="flex overflow-hidden rounded-sm">
          <div
            className="flex w-14 shrink-0 items-center justify-center text-sm font-semibold"
            style={{ backgroundColor: row.color, color: row.name === "B" ? "#161412" : "#f7f4ee" }}
          >
            {row.name}
          </div>
          <div className="flex flex-1 flex-wrap gap-1.5 bg-surface-2 p-1.5">
            {row.chips.map((chip, i) => (
              <span
                key={`${row.name}-${i}`}
                className="size-8 rounded-xs"
                style={{ backgroundColor: chip }}
              />
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

export function HomePage() {
  const hydrated = useHydrated();
  const boardsMap = useBoardStore((s) => s.boards);
  const duplicateBoard = useBoardStore((s) => s.duplicateBoard);
  const deleteBoard = useBoardStore((s) => s.deleteBoard);
  const importBoard = useBoardStore((s) => s.importBoard);
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const boards = hydrated ? listBoards(boardsMap) : [];

  async function onImport(file: File | undefined) {
    if (!file) return;
    try {
      const parsed = JSON.parse(await file.text()) as Board;
      if (!parsed || !Array.isArray(parsed.tiers) || !parsed.items || !parsed.placements) {
        throw new Error("Not a Rung list");
      }
      const id = importBoard(parsed);
      toast.success("Imported");
      void navigate({ to: "/b/$boardId", params: { boardId: id } });
    } catch {
      toast.error("Could not import that file");
    }
  }

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <header className="flex h-14 items-center justify-between px-4 md:px-8">
        <p className="font-serif text-2xl tracking-tight">Rung</p>
        <div className="flex items-center gap-2">
          <input
            ref={fileRef}
            type="file"
            accept="application/json"
            className="hidden"
            onChange={(e) => {
              void onImport(e.target.files?.[0]);
              e.target.value = "";
            }}
          />
          <Button variant="ghost" size="sm" onClick={() => fileRef.current?.click()}>
            <Upload className="size-4" />
            <span className="hidden sm:inline">Import</span>
          </Button>
          <Button size="sm" onClick={() => setOpen(true)}>
            <Plus className="size-4" />
            New list
          </Button>
        </div>
      </header>

      <main className="mx-auto grid max-w-6xl gap-10 px-4 py-8 md:grid-cols-[1.1fr_0.9fr] md:px-8 md:py-14">
        <section className="flex flex-col justify-center">
          <p className="mb-3 text-sm font-medium tracking-wide text-muted uppercase">Tier lists, on your terms</p>
          <h1 className="font-serif text-5xl leading-[1.05] tracking-tight md:text-6xl">
            Rank <em className="italic">anything</em>.
            <br />
            Name every rung.
          </h1>
          <p className="mt-4 max-w-md text-base leading-relaxed text-muted">
            Color the rows, drag in pictures from the web, and keep every list in this browser. No account.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Button size="lg" onClick={() => setOpen(true)}>
              Start a list
            </Button>
            <Button size="lg" variant="secondary" onClick={() => fileRef.current?.click()}>
              Import JSON
            </Button>
          </div>
        </section>
        <section className="hidden md:block">
          <HeroRungs />
        </section>
      </main>

      <section className="mx-auto max-w-6xl px-4 pb-16 md:px-8">
        <div className="mb-4 flex items-baseline justify-between">
          <h2 className="text-sm font-medium tracking-wide text-muted uppercase">Your lists</h2>
          {hydrated ? (
            <span className="text-xs text-subtle tabular-nums">{boards.length}</span>
          ) : null}
        </div>
        {!hydrated ? (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="h-36 rounded-lg bg-surface shadow-[var(--shadow-border)]" />
            ))}
          </div>
        ) : boards.length === 0 ? (
          <button
            type="button"
            onClick={() => setOpen(true)}
            className="flex w-full flex-col items-start gap-2 rounded-lg bg-surface p-5 text-left shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)]"
          >
            <Plus className="size-5 text-muted" />
            <p className="font-medium">No lists yet</p>
            <p className="text-sm text-muted">Create one and search the web for pictures to rank.</p>
          </button>
        ) : (
          <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {boards.map((board) => (
              <li key={board.id} className="relative">
                <Link
                  to="/b/$boardId"
                  params={{ boardId: board.id }}
                  className="block rounded-lg bg-surface p-4 shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)]"
                >
                  <MiniRungs board={board} />
                  <p className="mt-3 truncate font-medium">{board.title}</p>
                  <p className="text-xs text-muted">
                    {Object.keys(board.items).length} items · {formatUpdated(board.updatedAt)}
                  </p>
                </Link>
                <div className="absolute top-2 right-2">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <button
                        type="button"
                        className="inline-flex size-9 items-center justify-center rounded-sm bg-surface/80 text-muted hover:bg-surface-2 hover:text-fg"
                        aria-label={`${board.title} menu`}
                      >
                        <MoreHorizontal className="size-4" />
                      </button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem
                        onSelect={() => {
                          const id = duplicateBoard(board.id);
                          if (id) toast.success("Duplicated");
                        }}
                      >
                        <Copy className="size-4" />
                        Duplicate
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        className="text-danger"
                        onSelect={() => {
                          if (window.confirm(`Delete “${board.title}”?`)) deleteBoard(board.id);
                        }}
                      >
                        <Trash2 className="size-4" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>
      <NewBoardDialog open={open} onOpenChange={setOpen} />
    </div>
  );
}
