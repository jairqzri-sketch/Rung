import { useEffect, useState } from "react";
import { BATMAN_BOARD_ID, buildBatmanBoard } from "@/lib/seed-batman";
import { useBoardStore } from "@/lib/store";

function seedBatman() {
  const { boards } = useBoardStore.getState();
  if (boards[BATMAN_BOARD_ID]) return;
  useBoardStore.setState({
    boards: { ...boards, [BATMAN_BOARD_ID]: buildBatmanBoard() },
  });
}

export function useHydrated() {
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    let cancelled = false;
    const persist = useBoardStore.persist;

    const finish = () => {
      if (cancelled) return;
      seedBatman();
      setHydrated(true);
    };

    if (!persist) {
      finish();
      return;
    }

    const unsub = persist.onFinishHydration(finish);
    if (persist.hasHydrated()) {
      finish();
    } else {
      void persist.rehydrate();
    }

    return () => {
      cancelled = true;
      unsub?.();
    };
  }, []);

  return hydrated;
}
