import { createFileRoute, Link } from "@tanstack/react-router";
import { BoardEditor } from "@/components/board-editor";
import { Button } from "@/components/ui/button";
import { useHydrated } from "@/hooks/use-hydrated";
import { useBoardStore } from "@/lib/store";

export const Route = createFileRoute("/b/$boardId")({
  component: BoardPage,
});

function BoardPage() {
  const { boardId } = Route.useParams();
  const hydrated = useHydrated();
  const board = useBoardStore((s) => s.boards[boardId]);

  if (!hydrated) {
    return (
      <main className="flex min-h-dvh items-center justify-center bg-bg text-muted">
        Loading list…
      </main>
    );
  }

  if (!board) {
    return (
      <main className="flex min-h-dvh flex-col items-center justify-center gap-4 bg-bg px-6 text-center text-fg">
        <h1 className="font-serif text-3xl tracking-tight">List not found</h1>
        <p className="max-w-sm text-sm text-muted">
          This list is not in this browser. Lists are stored locally, so another device will not see them.
        </p>
        <Button asChild>
          <Link to="/">Back to Rung</Link>
        </Button>
      </main>
    );
  }

  return <BoardEditor board={board} />;
}
