import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as Link, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { _ as ArrowDown, a as Trash2, c as Plus, d as Ellipsis, f as Download, g as ArrowLeft, h as ArrowUp, l as Link2, m as Check, n as Upload, o as Search, r as Type, s as RotateCcw, t as X, u as ImagePlus } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Route } from "./router-YhcfWRqI.mjs";
import { a as DropdownMenuSeparator, h as useHydrated, i as DropdownMenuItem, l as UNRANKED, m as useBoardStore, n as DropdownMenu, o as DropdownMenuTrigger, p as slugify, r as DropdownMenuContent, s as Input, t as Button, u as cn } from "./use-hydrated-D8TOx3Dw.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/b._boardId-BaUGdT-F.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var INK = "#161412";
var PAPER = "#f7f4ee";
function parseHex(hex) {
	const raw = hex.replace("#", "").trim();
	const full = raw.length === 3 ? raw.split("").map((c) => c + c).join("") : raw;
	if (!/^[0-9a-fA-F]{6}$/.test(full)) return null;
	return {
		r: Number.parseInt(full.slice(0, 2), 16),
		g: Number.parseInt(full.slice(2, 4), 16),
		b: Number.parseInt(full.slice(4, 6), 16)
	};
}
function onColor(hex) {
	const rgb = parseHex(hex);
	if (!rgb) return INK;
	return (.2126 * rgb.r + .7152 * rgb.g + .0722 * rgb.b) / 255 > .58 ? INK : PAPER;
}
var TIER_SWATCHES = [
	"#e85d4c",
	"#e89a4c",
	"#e8c84c",
	"#7dbe6a",
	"#5aa0d6",
	"#8b86a8",
	"#d46a8a",
	"#c45c26",
	"#2f9e7b",
	"#3d6ea8",
	"#6b5b95",
	"#4a4a4e"
];
var TILE = 88;
var LABEL_W = 108;
var PAD = 18;
var GAP = 6;
var BG = "#0b0b0c";
var SURFACE = "#141416";
var FG = "#f3f1ec";
var MUTED = "#8c8a84";
function loadImage(src) {
	return new Promise((resolve) => {
		const img = new Image();
		img.crossOrigin = "anonymous";
		img.onload = () => resolve(img);
		img.onerror = () => resolve(null);
		img.src = src;
	});
}
function roundRect(ctx, x, y, w, h, r) {
	const radius = Math.min(r, w / 2, h / 2);
	ctx.beginPath();
	ctx.moveTo(x + radius, y);
	ctx.arcTo(x + w, y, x + w, y + h, radius);
	ctx.arcTo(x + w, y + h, x, y + h, radius);
	ctx.arcTo(x, y + h, x, y, radius);
	ctx.arcTo(x, y, x + w, y, radius);
	ctx.closePath();
}
function drawCover(ctx, img, x, y, size) {
	const scale = Math.max(size / img.width, size / img.height);
	const w = img.width * scale;
	const h = img.height * scale;
	const dx = x + (size - w) / 2;
	const dy = y + (size - h) / 2;
	ctx.save();
	roundRect(ctx, x, y, size, size, 6);
	ctx.clip();
	ctx.drawImage(img, dx, dy, w, h);
	ctx.restore();
}
async function exportBoardPng(board) {
	const rows = board.tiers.map((tier) => ({
		tier,
		ids: board.placements[tier.id] ?? []
	}));
	const maxItems = Math.max(1, ...rows.map((r) => r.ids.length), 4);
	const width = Math.max(720, 144 + maxItems * 94 + GAP);
	const titleH = 72;
	const height = 90 + rows.map(() => 108).reduce((a, b) => a + b, 0) + rows.length * 4;
	const uniqueUrls = [...new Set(Object.values(board.items).map((item) => item.imageUrl).filter((u) => Boolean(u)))];
	const loaded = await Promise.all(uniqueUrls.map(async (url) => [url, await loadImage(url)]));
	const images = new Map(loaded);
	const canvas = document.createElement("canvas");
	const scale = 2;
	canvas.width = width * scale;
	canvas.height = height * scale;
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("Could not export");
	ctx.scale(scale, scale);
	ctx.fillStyle = BG;
	ctx.fillRect(0, 0, width, height);
	ctx.fillStyle = FG;
	ctx.font = "500 32px \"Instrument Serif\", Georgia, serif";
	ctx.fillText(board.title || "Untitled", PAD, 48);
	ctx.fillStyle = MUTED;
	ctx.font = "500 12px Figtree, system-ui, sans-serif";
	ctx.fillText("Rung", width - PAD - 40, 46);
	let y = titleH;
	for (const row of rows) {
		const h = 108;
		ctx.fillStyle = SURFACE;
		roundRect(ctx, PAD, y, width - 36, h, 10);
		ctx.fill();
		ctx.fillStyle = row.tier.color;
		roundRect(ctx, PAD, y, LABEL_W, h, 10);
		ctx.fill();
		ctx.fillRect(116, y, 10, h);
		ctx.fillStyle = onColor(row.tier.color);
		ctx.font = "600 20px Figtree, system-ui, sans-serif";
		ctx.textAlign = "center";
		ctx.textBaseline = "middle";
		ctx.fillText(row.tier.name.slice(0, 12), 72, y + h / 2, 96);
		ctx.textAlign = "left";
		ctx.textBaseline = "alphabetic";
		let x = 136;
		for (const id of row.ids) {
			const item = board.items[id];
			if (!item) continue;
			const img = item.imageUrl ? images.get(item.imageUrl) : null;
			if (img) drawCover(ctx, img, x, y + 10, TILE);
			else {
				ctx.fillStyle = "#1c1c1f";
				roundRect(ctx, x, y + 10, TILE, TILE, 6);
				ctx.fill();
				ctx.fillStyle = FG;
				ctx.font = "600 11px Figtree, system-ui, sans-serif";
				ctx.textAlign = "center";
				ctx.textBaseline = "middle";
				const label = item.label || "?";
				ctx.fillText(label.slice(0, 10), x + TILE / 2, y + 10 + TILE / 2, 80);
				ctx.textAlign = "left";
				ctx.textBaseline = "alphabetic";
			}
			x += 94;
			if (x > width - PAD - TILE) break;
		}
		y += 112;
	}
	return new Promise((resolve, reject) => {
		canvas.toBlob((blob) => {
			if (!blob) {
				reject(/* @__PURE__ */ new Error("Could not export this list. Try again without hotlinked images."));
				return;
			}
			const a = document.createElement("a");
			a.href = URL.createObjectURL(blob);
			a.download = `${slugify(board.title)}.png`;
			a.click();
			setTimeout(() => URL.revokeObjectURL(a.href), 4e3);
			resolve();
		}, "image/png");
	});
}
function exportBoardJson(board) {
	const blob = new Blob([JSON.stringify(board, null, 2)], { type: "application/json" });
	const a = document.createElement("a");
	a.href = URL.createObjectURL(blob);
	a.download = `${slugify(board.title)}.json`;
	a.click();
	setTimeout(() => URL.revokeObjectURL(a.href), 4e3);
}
var MAX_EDGE = 480;
var JPEG_QUALITY = .84;
function resizeImageFile(file) {
	return new Promise((resolve, reject) => {
		const url = URL.createObjectURL(file);
		const image = new Image();
		image.onload = () => {
			URL.revokeObjectURL(url);
			const scale = Math.min(1, MAX_EDGE / Math.max(image.width, image.height));
			const width = Math.max(1, Math.round(image.width * scale));
			const height = Math.max(1, Math.round(image.height * scale));
			const canvas = document.createElement("canvas");
			canvas.width = width;
			canvas.height = height;
			const ctx = canvas.getContext("2d");
			if (!ctx) {
				reject(/* @__PURE__ */ new Error("Could not read that image"));
				return;
			}
			ctx.drawImage(image, 0, 0, width, height);
			resolve(canvas.toDataURL("image/jpeg", JPEG_QUALITY));
		};
		image.onerror = () => {
			URL.revokeObjectURL(url);
			reject(/* @__PURE__ */ new Error("Could not read that image"));
		};
		image.src = url;
	});
}
function looksLikeImageUrl(value) {
	try {
		const url = new URL(value);
		if (!/^https?:$/.test(url.protocol)) return false;
		return true;
	} catch {
		return false;
	}
}
function ColorField({ value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-wrap gap-1.5",
			children: TIER_SWATCHES.map((color) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": `Use ${color}`,
				onClick: () => onChange(color),
				className: cn("size-7 rounded-xs transition-[transform,box-shadow] duration-150 ease-out", value.toLowerCase() === color.toLowerCase() ? "scale-95 shadow-[0_0_0_2px_var(--color-bg),0_0_0_4px_var(--color-accent)]" : "shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]"),
				style: { backgroundColor: color }
			}, color))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "flex h-11 items-center gap-2 rounded-sm bg-surface-2 px-2 shadow-[var(--shadow-border)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "color",
				value,
				onChange: (e) => onChange(e.target.value),
				className: "size-7 cursor-pointer rounded-xs bg-transparent",
				"aria-label": "Custom color"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value,
				onChange: (e) => {
					const next = e.target.value.trim();
					if (/^#?[0-9a-fA-F]{0,6}$/.test(next)) onChange(next.startsWith("#") ? next : `#${next}`);
				},
				className: "min-w-0 flex-1 bg-transparent font-mono text-sm text-fg outline-none",
				spellCheck: false
			})]
		})]
	});
}
var UA_HEADERS = { Accept: "application/json" };
function wikiApi(host) {
	return `https://${host}/w/api.php`;
}
async function fetchJson(url) {
	const response = await fetch(url.toString(), { headers: UA_HEADERS });
	if (!response.ok) throw new Error(`Search failed (${response.status})`);
	return response.json();
}
function pagesFrom(payload) {
	if (!payload || typeof payload !== "object") return [];
	const query = payload.query;
	if (!query?.pages) return [];
	return Object.values(query.pages).sort((a, b) => {
		return (a.index ?? 0) - (b.index ?? 0);
	});
}
async function searchWikipedia(query) {
	const url = new URL(wikiApi("en.wikipedia.org"));
	url.searchParams.set("action", "query");
	url.searchParams.set("format", "json");
	url.searchParams.set("origin", "*");
	url.searchParams.set("generator", "search");
	url.searchParams.set("gsrsearch", query);
	url.searchParams.set("gsrlimit", "18");
	url.searchParams.set("prop", "pageimages");
	url.searchParams.set("piprop", "thumbnail|original");
	url.searchParams.set("pithumbsize", "400");
	const pages = pagesFrom(await fetchJson(url));
	const hits = [];
	for (const page of pages) {
		const thumb = page.thumbnail?.source;
		if (!thumb) continue;
		hits.push({
			id: `wiki-${page.pageid ?? page.title ?? thumb}`,
			title: (page.title ?? "Untitled").replace(/_/g, " "),
			thumbUrl: thumb,
			fullUrl: page.original?.source ?? thumb,
			source: "wikipedia"
		});
	}
	return hits;
}
async function searchCommons(query) {
	const url = new URL(wikiApi("commons.wikimedia.org"));
	url.searchParams.set("action", "query");
	url.searchParams.set("format", "json");
	url.searchParams.set("origin", "*");
	url.searchParams.set("generator", "search");
	url.searchParams.set("gsrsearch", query);
	url.searchParams.set("gsrnamespace", "6");
	url.searchParams.set("gsrlimit", "18");
	url.searchParams.set("prop", "imageinfo");
	url.searchParams.set("iiprop", "url|mime");
	url.searchParams.set("iiurlwidth", "400");
	const pages = pagesFrom(await fetchJson(url));
	const allowed = /* @__PURE__ */ new Set([
		"image/jpeg",
		"image/png",
		"image/webp",
		"image/gif"
	]);
	const hits = [];
	for (const page of pages) {
		const info = page.imageinfo?.[0];
		if (!info?.thumburl && !info?.url) continue;
		if (info.mime && !allowed.has(info.mime)) continue;
		const title = (page.title ?? "Image").replace(/^File:/, "").replace(/_/g, " ");
		hits.push({
			id: `commons-${page.pageid ?? title}`,
			title: title.replace(/\.[a-z0-9]+$/i, ""),
			thumbUrl: info.thumburl ?? info.url ?? "",
			fullUrl: info.url ?? info.thumburl ?? "",
			source: "commons"
		});
	}
	return hits.filter((h) => h.thumbUrl);
}
function dedupe(hits) {
	const seen = /* @__PURE__ */ new Set();
	const out = [];
	for (const hit of hits) {
		const key = hit.thumbUrl.split("?")[0] ?? hit.thumbUrl;
		if (seen.has(key)) continue;
		seen.add(key);
		out.push(hit);
	}
	return out;
}
async function searchImages(query) {
	const q = query.trim().slice(0, 80);
	if (!q) return [];
	const settled = await Promise.allSettled([searchWikipedia(q), searchCommons(q)]);
	const wiki = settled[0]?.status === "fulfilled" ? settled[0].value : [];
	const commons = settled[1]?.status === "fulfilled" ? settled[1].value : [];
	if (wiki.length === 0 && commons.length === 0) {
		if (settled.every((s) => s.status === "rejected")) throw new Error("Image search is unavailable right now. Try a link or upload.");
	}
	return dedupe([...wiki, ...commons]).slice(0, 30);
}
function ImageFinder({ board, className }) {
	const addItem = useBoardStore((s) => s.addItem);
	const fileRef = (0, import_react.useRef)(null);
	const [tab, setTab] = (0, import_react.useState)("search");
	const [query, setQuery] = (0, import_react.useState)("");
	const [hits, setHits] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [link, setLink] = (0, import_react.useState)("");
	const [label, setLabel] = (0, import_react.useState)("");
	const existing = new Set(Object.values(board.items).map((item) => item.imageUrl).filter(Boolean));
	function pushItem(item) {
		if (item.imageUrl && existing.has(item.imageUrl)) {
			toast("Already on the board");
			return;
		}
		if (!addItem(board.id, item)) {
			toast.error("This list is full (160 items).");
			return;
		}
		toast.success("Added to unranked");
	}
	async function onSearch(event) {
		event?.preventDefault();
		const q = query.trim();
		if (!q) return;
		setBusy(true);
		setError(null);
		try {
			const results = await searchImages(q);
			setHits(results);
			if (results.length === 0) setError("No images found. Try a simpler name.");
		} catch (err) {
			setHits([]);
			setError(err instanceof Error ? err.message : "Search failed");
		} finally {
			setBusy(false);
		}
	}
	async function onFiles(files) {
		if (!files?.length) return;
		for (const file of [...files].slice(0, 24)) {
			if (!file.type.startsWith("image/")) continue;
			try {
				const dataUrl = await resizeImageFile(file);
				pushItem({
					label: file.name.replace(/\.[^.]+$/, ""),
					imageUrl: dataUrl
				});
			} catch {
				toast.error(`Could not read ${file.name}`);
			}
		}
	}
	function onAddLink() {
		const url = link.trim();
		if (!looksLikeImageUrl(url)) {
			toast.error("Use a full http(s) image link");
			return;
		}
		pushItem({
			label: "Image",
			imageUrl: url,
			sourceUrl: url
		});
		setLink("");
	}
	function onAddText() {
		const text = label.trim();
		if (!text) return;
		pushItem({
			label: text,
			imageUrl: null
		});
		setLabel("");
	}
	const tabs = [
		{
			id: "search",
			icon: Search,
			label: "Search"
		},
		{
			id: "upload",
			icon: Upload,
			label: "Upload"
		},
		{
			id: "link",
			icon: Link2,
			label: "Link"
		},
		{
			id: "text",
			icon: Type,
			label: "Text"
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex h-full min-h-0 flex-col", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-1 p-1",
				children: tabs.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setTab(item.id),
					className: cn("flex h-10 flex-1 items-center justify-center gap-1.5 rounded-xs text-xs font-medium transition-colors duration-150", tab === item.id ? "bg-surface-2 text-fg" : "text-muted hover:text-fg"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden sm:inline",
						children: item.label
					})]
				}, item.id))
			}),
			tab === "search" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: onSearch,
				className: "flex gap-2 px-3 pb-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: query,
					onChange: (e) => setQuery(e.target.value),
					placeholder: "Pizza, Ghibli, sneakers…",
					"aria-label": "Search images"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					disabled: busy || !query.trim(),
					className: "shrink-0",
					children: busy ? "…" : "Find"
				})]
			}) : null,
			tab === "upload" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-3 pb-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref: fileRef,
					type: "file",
					accept: "image/*",
					multiple: true,
					className: "hidden",
					onChange: (e) => {
						onFiles(e.target.files);
						e.target.value = "";
					}
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => fileRef.current?.click(),
					className: "flex h-28 w-full flex-col items-center justify-center gap-2 rounded-md bg-surface-2 text-sm text-muted shadow-[var(--shadow-border)] transition-colors duration-150 hover:text-fg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-5" }), "Drop or choose images"]
				})]
			}) : null,
			tab === "link" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2 px-3 pb-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: link,
					onChange: (e) => setLink(e.target.value),
					placeholder: "https://…",
					onKeyDown: (e) => {
						if (e.key === "Enter") onAddLink();
					}
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					onClick: onAddLink,
					className: "shrink-0",
					children: "Add"
				})]
			}) : null,
			tab === "text" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2 px-3 pb-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: label,
					onChange: (e) => setLabel(e.target.value),
					placeholder: "A name, no picture",
					onKeyDown: (e) => {
						if (e.key === "Enter") onAddText();
					}
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					onClick: onAddText,
					className: "shrink-0",
					children: "Add"
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-h-0 flex-1 overflow-y-auto px-3 pb-4",
				onDragOver: (e) => {
					if ([...e.dataTransfer.types].includes("Files")) e.preventDefault();
				},
				onDrop: (e) => {
					if (e.dataTransfer.files.length) {
						e.preventDefault();
						onFiles(e.dataTransfer.files);
					}
				},
				children: [
					tab === "search" && error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-sm text-muted",
						children: error
					}) : null,
					tab === "search" && hits.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-3 gap-2",
						children: hits.map((hit) => {
							const added = existing.has(hit.thumbUrl) || existing.has(hit.fullUrl);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								disabled: added,
								onClick: () => pushItem({
									label: hit.title,
									imageUrl: hit.thumbUrl,
									sourceUrl: hit.fullUrl
								}),
								"aria-label": added ? `${hit.title} (added)` : `Add ${hit.title}`,
								className: "group relative aspect-square overflow-hidden rounded-xs bg-surface-2 shadow-[var(--shadow-border)] disabled:opacity-50",
								title: hit.title,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: hit.thumbUrl,
									alt: "",
									className: "size-full object-cover outline outline-1 -outline-offset-1 outline-fg/10 transition-transform duration-200 ease-out group-hover:scale-105"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "pointer-events-none absolute inset-x-0 bottom-0 truncate bg-bg/70 px-1 py-0.5 text-left text-xs text-fg",
									children: added ? "Added" : hit.title
								})]
							}, hit.id);
						})
					}) : null,
					tab === "search" && !busy && hits.length === 0 && !error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Search Wikipedia and Wikimedia Commons for pictures. Click a result to drop it into Unranked."
					}) : null,
					tab === "upload" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Images are resized and stored in this browser."
					}) : null
				]
			})
		]
	});
}
function ItemTile({ item, selected, dimmed, onPointerDown, onRemove }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("group relative size-16 shrink-0 touch-manipulation md:size-20", dimmed && "opacity-40"),
		"data-item-id": item.id,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onPointerDown: (event) => {
					event.stopPropagation();
					onPointerDown(event);
				},
				onClick: (event) => event.stopPropagation(),
				"aria-pressed": selected,
				"aria-label": item.label || "Item",
				className: cn("size-full overflow-hidden rounded-xs bg-surface-2 text-left shadow-[var(--shadow-border)]", "transition-[box-shadow,transform] duration-150 ease-out", selected && "shadow-[0_0_0_2px_var(--color-bg),0_0_0_4px_var(--color-accent)]"),
				children: item.imageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: item.imageUrl,
					alt: "",
					draggable: false,
					className: "size-full object-cover outline outline-1 -outline-offset-1 outline-fg/10"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex size-full items-center justify-center px-1 text-center text-xs leading-tight font-medium text-fg",
					children: item.label || "Item"
				})
			}),
			item.imageUrl && item.label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "pointer-events-none absolute inset-x-0 bottom-0 truncate bg-bg/70 px-1 py-0.5 text-xs text-fg opacity-0 transition-opacity duration-150 group-hover:opacity-100",
				children: item.label
			}) : null,
			onRemove ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": `Remove ${item.label || "item"}`,
				onClick: (e) => {
					e.stopPropagation();
					onRemove();
				},
				className: "absolute -top-1.5 -right-1.5 z-10 hidden size-6 items-center justify-center rounded-full bg-surface-2 text-fg shadow-[var(--shadow-border)] group-hover:flex group-focus-within:flex",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" })
			}) : null
		]
	});
}
function findDrop(clientX, clientY) {
	const stack = document.elementsFromPoint(clientX, clientY);
	for (const el of stack) {
		if (!(el instanceof HTMLElement)) continue;
		const itemId = el.closest("[data-item-id]")?.getAttribute("data-item-id");
		const zoneEl = el.closest("[data-drop-zone]");
		if (!zoneEl) continue;
		const zone = zoneEl.getAttribute("data-drop-zone");
		if (!zone) continue;
		if (itemId) {
			const row = [...zoneEl.querySelectorAll("[data-item-id]")];
			const index = row.findIndex((n) => n.getAttribute("data-item-id") === itemId);
			return {
				zone,
				index: index < 0 ? row.length : index
			};
		}
		return {
			zone,
			index: zoneEl.querySelectorAll("[data-item-id]").length
		};
	}
	return null;
}
function ZoneRow({ zone, label, color, ids, items, selectedId, draggingId, over, onPointerDown, onRemove, onPlace, onName, onEdit, trailing }) {
	const isOver = over?.zone === zone;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-20 overflow-hidden rounded-md bg-surface shadow-[var(--shadow-border)] md:min-h-24",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex w-16 shrink-0 flex-col md:w-24",
				style: color ? {
					backgroundColor: color,
					color: onColor(color)
				} : void 0,
				children: onName ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: label,
					maxLength: 18,
					"aria-label": "Tier name",
					onChange: (e) => onName(e.target.value),
					className: "h-full w-full bg-transparent px-1.5 text-center text-sm font-semibold tracking-tight outline-none md:text-base",
					style: { color: color ? onColor(color) : void 0 }
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex h-full items-center justify-center px-2 text-center text-xs font-medium tracking-wide text-muted uppercase",
					children: label
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				"data-drop-zone": zone,
				onClick: () => {
					if (selectedId) onPlace();
				},
				className: cn("flex min-h-20 min-w-0 flex-1 flex-wrap content-start items-start gap-2 p-2 md:min-h-24", isOver && "bg-surface-2", selectedId && "cursor-copy"),
				children: [
					ids.map((id, index) => {
						const item = items[id];
						if (!item) return null;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [isOver && over.index === index ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-0 -left-1.5 h-16 w-0.5 rounded-full bg-accent md:h-20" }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemTile, {
								item,
								selected: selectedId === id,
								dimmed: draggingId === id,
								onPointerDown: (e) => onPointerDown(e, id),
								onRemove: () => onRemove(id)
							})]
						}, id);
					}),
					isOver && over.index >= ids.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-16 w-0.5 rounded-full bg-accent md:h-20" }) : null,
					ids.length === 0 && !isOver ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "self-center px-1 text-xs text-subtle",
						children: selectedId ? "Tap to place" : "Drop here"
					}) : null
				]
			}),
			onEdit || trailing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex shrink-0 flex-col justify-center gap-0.5 border-l border-border p-1",
				children: [onEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onEdit,
					className: "inline-flex size-8 items-center justify-center rounded-xs text-muted hover:bg-surface-2 hover:text-fg",
					"aria-label": `Customize ${label}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, { className: "size-4" })
				}) : null, trailing]
			}) : null
		]
	});
}
function BoardEditor({ board }) {
	const setTitle = useBoardStore((s) => s.setTitle);
	const setTierName = useBoardStore((s) => s.setTierName);
	const setTierColor = useBoardStore((s) => s.setTierColor);
	const addTier = useBoardStore((s) => s.addTier);
	const removeTier = useBoardStore((s) => s.removeTier);
	const moveTier = useBoardStore((s) => s.moveTier);
	const moveItem = useBoardStore((s) => s.moveItem);
	const removeItem = useBoardStore((s) => s.removeItem);
	const resetRanks = useBoardStore((s) => s.resetRanks);
	const deleteBoard = useBoardStore((s) => s.deleteBoard);
	const addItem = useBoardStore((s) => s.addItem);
	const navigate = useNavigate();
	const [title, setTitleLocal] = (0, import_react.useState)(board.title);
	const [finderOpen, setFinderOpen] = (0, import_react.useState)(false);
	const [editingTier, setEditingTier] = (0, import_react.useState)(null);
	const [selectedId, setSelectedId] = (0, import_react.useState)(null);
	const [draggingId, setDraggingId] = (0, import_react.useState)(null);
	const [over, setOver] = (0, import_react.useState)(null);
	const [ghost, setGhost] = (0, import_react.useState)(null);
	const dragRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		setTitleLocal(board.title);
	}, [board.title]);
	(0, import_react.useEffect)(() => {
		if (window.matchMedia("(min-width: 768px)").matches) setFinderOpen(true);
	}, []);
	(0, import_react.useEffect)(() => {
		const onPaste = (event) => {
			const files = [...event.clipboardData?.files ?? []].filter((file) => file.type.startsWith("image/"));
			if (files.length === 0) return;
			event.preventDefault();
			(async () => {
				for (const file of files) try {
					const dataUrl = await resizeImageFile(file);
					addItem(board.id, {
						label: file.name.replace(/\.[^.]+$/, "") || "Pasted",
						imageUrl: dataUrl
					});
				} catch {
					toast.error("Could not paste that image");
				}
			})();
		};
		window.addEventListener("paste", onPaste);
		return () => window.removeEventListener("paste", onPaste);
	}, [addItem, board.id]);
	const editing = board.tiers.find((t) => t.id === editingTier) ?? null;
	const placeSelected = (0, import_react.useCallback)((zone, index) => {
		if (!selectedId) return;
		moveItem(board.id, selectedId, zone, index);
		setSelectedId(null);
	}, [
		board.id,
		moveItem,
		selectedId
	]);
	const onPointerDown = (0, import_react.useCallback)((event, itemId) => {
		if (event.button !== 0) return;
		const rect = event.currentTarget.getBoundingClientRect();
		dragRef.current = {
			itemId,
			pointerId: event.pointerId,
			startX: event.clientX,
			startY: event.clientY,
			active: false,
			ox: event.clientX - rect.left,
			oy: event.clientY - rect.top,
			w: rect.width,
			h: rect.height
		};
		const onMove = (ev) => {
			const drag = dragRef.current;
			if (!drag || ev.pointerId !== drag.pointerId) return;
			const dx = ev.clientX - drag.startX;
			const dy = ev.clientY - drag.startY;
			if (!drag.active && Math.hypot(dx, dy) > 16) {
				drag.active = true;
				setDraggingId(drag.itemId);
				setSelectedId(null);
				const item = board.items[drag.itemId];
				if (item) setGhost({
					item,
					x: ev.clientX,
					y: ev.clientY,
					w: drag.w,
					h: drag.h,
					ox: drag.ox,
					oy: drag.oy
				});
			}
			if (drag.active) {
				ev.preventDefault();
				setGhost((g) => g ? {
					...g,
					x: ev.clientX,
					y: ev.clientY
				} : g);
				setOver(findDrop(ev.clientX, ev.clientY));
			}
		};
		const onUp = (ev) => {
			const drag = dragRef.current;
			window.removeEventListener("pointermove", onMove);
			window.removeEventListener("pointerup", onUp);
			window.removeEventListener("pointercancel", onUp);
			dragRef.current = null;
			if (!drag || ev.pointerId !== drag.pointerId) return;
			if (drag.active) {
				const dest = findDrop(ev.clientX, ev.clientY);
				const dist = Math.hypot(ev.clientX - drag.startX, ev.clientY - drag.startY);
				if (dest && dist > 16) moveItem(board.id, drag.itemId, dest.zone, dest.index);
				else setSelectedId((cur) => cur === drag.itemId ? null : drag.itemId);
				setDraggingId(null);
				setGhost(null);
				setOver(null);
			} else setSelectedId((cur) => cur === drag.itemId ? null : drag.itemId);
		};
		window.addEventListener("pointermove", onMove, { passive: false });
		window.addEventListener("pointerup", onUp);
		window.addEventListener("pointercancel", onUp);
	}, [
		board.id,
		board.items,
		moveItem
	]);
	async function handleExportPng() {
		try {
			await exportBoardPng(board);
			toast.success("Saved PNG");
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Export failed");
		}
	}
	const unranked = board.placements["unranked"] ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex h-14 shrink-0 items-center gap-2 border-b border-border px-3 md:px-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "ghost",
						size: "icon-sm",
						"aria-label": "Back",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: title,
						onChange: (e) => setTitleLocal(e.target.value),
						onBlur: () => setTitle(board.id, title),
						onKeyDown: (e) => {
							if (e.key === "Enter") e.target.blur();
						},
						className: "min-w-0 flex-1 bg-transparent font-serif text-xl tracking-tight outline-none md:text-2xl",
						"aria-label": "List title"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "secondary",
						size: "sm",
						className: "md:hidden",
						onClick: () => setFinderOpen(true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-4" }), "Images"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "secondary",
						size: "sm",
						className: "hidden md:inline-flex",
						onClick: () => setFinderOpen((v) => !v),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-4" }), finderOpen ? "Hide" : "Images"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon-sm",
							"aria-label": "List menu",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, { className: "size-4" })
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
						align: "end",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
								onSelect: () => void handleExportPng(),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), "Download PNG"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
								onSelect: () => exportBoardJson(board),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), "Export JSON"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
								onSelect: () => resetRanks(board.id),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Reset to unranked"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
								className: "text-danger",
								onSelect: () => {
									if (window.confirm("Delete this list? This cannot be undone.")) {
										deleteBoard(board.id);
										navigate({ to: "/" });
									}
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), "Delete list"]
							})
						]
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 flex-1 flex-col",
					onDragOver: (e) => {
						if ([...e.dataTransfer.types].includes("Files")) e.preventDefault();
					},
					onDrop: (e) => {
						const files = e.dataTransfer.files;
						if (!files.length) return;
						e.preventDefault();
						(async () => {
							for (const file of [...files].slice(0, 24)) {
								if (!file.type.startsWith("image/")) continue;
								try {
									const dataUrl = await resizeImageFile(file);
									addItem(board.id, {
										label: file.name.replace(/\.[^.]+$/, ""),
										imageUrl: dataUrl
									});
								} catch {
									toast.error(`Could not read ${file.name}`);
								}
							}
						})();
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-h-0 flex-1 space-y-1.5 overflow-y-auto p-3 md:p-5",
						children: [board.tiers.map((tier, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoneRow, {
							zone: tier.id,
							label: tier.name,
							color: tier.color,
							ids: board.placements[tier.id] ?? [],
							items: board.items,
							selectedId,
							draggingId,
							over,
							onPointerDown,
							onRemove: (id) => removeItem(board.id, id),
							onPlace: () => placeSelected(tier.id, (board.placements[tier.id] ?? []).length),
							onName: (name) => setTierName(board.id, tier.id, name),
							onEdit: () => setEditingTier(tier.id),
							trailing: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: index === 0,
								onClick: () => moveTier(board.id, tier.id, "up"),
								className: "inline-flex size-8 items-center justify-center rounded-xs text-muted hover:bg-surface-2 hover:text-fg disabled:opacity-30",
								"aria-label": "Move rung up",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "size-3.5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: index === board.tiers.length - 1,
								onClick: () => moveTier(board.id, tier.id, "down"),
								className: "inline-flex size-8 items-center justify-center rounded-xs text-muted hover:bg-surface-2 hover:text-fg disabled:opacity-30",
								"aria-label": "Move rung down",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "size-3.5" })
							})] })
						}, tier.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "ghost",
							className: "w-full text-muted",
							onClick: () => {
								if (board.tiers.length >= 12) {
									toast.error("12 rungs is the maximum");
									return;
								}
								addTier(board.id);
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Add rung"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-t border-border bg-bg p-3 md:px-5 md:pb-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoneRow, {
							zone: UNRANKED,
							label: "Unranked",
							ids: unranked,
							items: board.items,
							selectedId,
							draggingId,
							over,
							onPointerDown,
							onRemove: (id) => removeItem(board.id, id),
							onPlace: () => placeSelected(UNRANKED, unranked.length)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 hidden text-xs text-subtle md:block",
							children: "Drag tiles onto a rung, or tap a tile then tap a row. Search the web from the images panel."
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: cn("hidden w-80 shrink-0 flex-col border-l border-border bg-surface md:flex", finderOpen ? "md:flex" : "md:hidden"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex h-12 items-center justify-between border-b border-border px-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: "Find images"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setFinderOpen(false),
							className: "inline-flex size-8 items-center justify-center rounded-xs text-muted hover:bg-surface-2 hover:text-fg",
							"aria-label": "Close images",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageFinder, {
						board,
						className: "min-h-0 flex-1"
					})]
				})]
			}),
			finderOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-40 flex flex-col bg-bg md:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex h-14 items-center justify-between border-b border-border px-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: "Find images"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon-sm",
						onClick: () => setFinderOpen(false),
						"aria-label": "Close",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageFinder, {
					board,
					className: "min-h-0 flex-1"
				})]
			}) : null,
			editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 flex items-end justify-center bg-bg/80 p-3 sm:items-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-sm rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-4 flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-serif text-2xl tracking-tight",
								children: "Rung"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: "Name and color this row."
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setEditingTier(null),
								className: "inline-flex size-9 items-center justify-center rounded-sm text-muted hover:bg-surface-2 hover:text-fg",
								"aria-label": "Close",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mb-3 block text-sm font-medium text-muted",
							children: ["Name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								className: "mt-1.5",
								value: editing.name,
								maxLength: 18,
								onChange: (e) => setTierName(board.id, editing.id, e.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-1.5 text-sm font-medium text-muted",
							children: "Color"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColorField, {
							value: editing.color,
							onChange: (color) => setTierColor(board.id, editing.id, color)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "danger",
								className: "flex-1",
								disabled: board.tiers.length <= 1,
								onClick: () => {
									removeTier(board.id, editing.id);
									setEditingTier(null);
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), "Remove"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								className: "flex-1",
								onClick: () => setEditingTier(null),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }), "Done"]
							})]
						})
					]
				})
			}) : null,
			ghost ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none fixed z-50 overflow-hidden rounded-xs shadow-[var(--shadow-border)]",
				style: {
					width: ghost.w,
					height: ghost.h,
					left: ghost.x - ghost.ox,
					top: ghost.y - ghost.oy
				},
				children: ghost.item.imageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: ghost.item.imageUrl,
					alt: "",
					className: "size-full object-cover"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex size-full items-center justify-center bg-surface-2 px-1 text-center text-xs font-medium",
					children: ghost.item.label
				})
			}) : null
		]
	});
}
function BoardPage() {
	const { boardId } = Route.useParams();
	const hydrated = useHydrated();
	const board = useBoardStore((s) => s.boards[boardId]);
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "flex min-h-dvh items-center justify-center bg-bg text-muted",
		children: "Loading list…"
	});
	if (!board) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-dvh flex-col items-center justify-center gap-4 bg-bg px-6 text-center text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-serif text-3xl tracking-tight",
				children: "List not found"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-sm text-sm text-muted",
				children: "This list is not in this browser. Lists are stored locally, so another device will not see them."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					children: "Back to Rung"
				})
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoardEditor, { board });
}
//#endregion
export { BoardPage as component };
