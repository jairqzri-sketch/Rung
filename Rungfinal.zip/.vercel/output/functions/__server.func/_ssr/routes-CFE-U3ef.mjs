import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as Link, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as Trash2, c as Plus, d as Ellipsis, n as Upload, p as Copy, t as X } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as DialogOverlay$1, i as DialogDescription$1, n as DialogClose, o as DialogPortal, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { c as TEMPLATES, d as formatUpdated, f as listBoards, h as useHydrated, i as DropdownMenuItem, m as useBoardStore, n as DropdownMenu, o as DropdownMenuTrigger, r as DropdownMenuContent, s as Input, t as Button, u as cn } from "./use-hydrated-D8TOx3Dw.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CFE-U3ef.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Dialog = Dialog$1;
function DialogOverlay({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
		className: cn("fixed inset-0 z-50 bg-bg/80 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
		...props
	});
}
function DialogContent({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
		className: cn("fixed top-1/2 left-1/2 z-50 w-[min(calc(100vw-1.5rem),28rem)] -translate-x-1/2 -translate-y-1/2 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]", "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
			className: "absolute top-3 right-3 inline-flex size-9 items-center justify-center rounded-sm text-muted transition-colors duration-150 hover:bg-surface-2 hover:text-fg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent",
			"aria-label": "Close",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
		})]
	})] });
}
function DialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("mb-4 pr-8", className),
		...props
	});
}
function DialogTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
		className: cn("font-serif text-2xl leading-tight tracking-tight text-fg", className),
		...props
	});
}
function DialogDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
		className: cn("mt-1 text-sm text-muted", className),
		...props
	});
}
function NewBoardDialog({ open, onOpenChange }) {
	const navigate = useNavigate();
	const createBoard = useBoardStore((s) => s.createBoard);
	const [title, setTitle] = (0, import_react.useState)("");
	const [template, setTemplate] = (0, import_react.useState)("classic");
	function handleCreate() {
		const id = createBoard(title || "Untitled", template);
		setTitle("");
		setTemplate("classic");
		onOpenChange(false);
		navigate({
			to: "/b/$boardId",
			params: { boardId: id }
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "New list" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Pick a starting set of rungs. You can rename and recolor every one." })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mb-3 block text-sm font-medium text-muted",
				children: ["Name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "mt-1.5",
					value: title,
					placeholder: "Weekend movies",
					onChange: (e) => setTitle(e.target.value),
					onKeyDown: (e) => {
						if (e.key === "Enter") handleCreate();
					},
					autoFocus: true
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-sm font-medium text-muted",
				children: "Rungs"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-2",
				children: TEMPLATES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setTemplate(item.id),
					className: cn("rounded-md bg-surface-2 p-3 text-left transition-[box-shadow,transform] duration-150 ease-out", template === item.id ? "shadow-[0_0_0_1px_var(--color-accent)]" : "shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-2 flex h-2 overflow-hidden rounded-xs",
							children: item.tiers.map((tier) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex-1",
								style: { backgroundColor: tier.color }
							}, tier.name))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm font-medium text-fg",
							children: item.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted",
							children: item.hint
						})
					]
				}, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-4 w-full",
				onClick: handleCreate,
				children: "Create list"
			})
		] })
	});
}
function MiniRungs({ board }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-col gap-1",
		children: board.tiers.slice(0, 6).map((tier) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex h-2 overflow-hidden rounded-xs",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "w-8 shrink-0",
				style: { backgroundColor: tier.color }
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "flex-1 bg-surface-2" })]
		}, tier.id))
	});
}
function HeroRungs() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-col gap-1.5 rounded-xl bg-surface p-3 shadow-[var(--shadow-border)]",
		children: [
			{
				name: "S",
				color: "#e85d4c",
				chips: [
					"#d8d2c6",
					"#8c8a84",
					"#f3f1ec"
				]
			},
			{
				name: "A",
				color: "#e89a4c",
				chips: ["#cfc8bb", "#6b6964"]
			},
			{
				name: "B",
				color: "#e8c84c",
				chips: [
					"#8c8a84",
					"#d8d2c6",
					"#6b6964",
					"#cfc8bb"
				]
			},
			{
				name: "C",
				color: "#7dbe6a",
				chips: ["#6b6964"]
			},
			{
				name: "D",
				color: "#5aa0d6",
				chips: ["#d8d2c6", "#8c8a84"]
			}
		].map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex overflow-hidden rounded-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex w-14 shrink-0 items-center justify-center text-sm font-semibold",
				style: {
					backgroundColor: row.color,
					color: row.name === "B" ? "#161412" : "#f7f4ee"
				},
				children: row.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-1 flex-wrap gap-1.5 bg-surface-2 p-1.5",
				children: row.chips.map((chip, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "size-8 rounded-xs",
					style: { backgroundColor: chip }
				}, `${row.name}-${i}`))
			})]
		}, row.name))
	});
}
function HomePage() {
	const hydrated = useHydrated();
	const boardsMap = useBoardStore((s) => s.boards);
	const duplicateBoard = useBoardStore((s) => s.duplicateBoard);
	const deleteBoard = useBoardStore((s) => s.deleteBoard);
	const importBoard = useBoardStore((s) => s.importBoard);
	const navigate = useNavigate();
	const [open, setOpen] = (0, import_react.useState)(false);
	const fileRef = (0, import_react.useRef)(null);
	const boards = hydrated ? listBoards(boardsMap) : [];
	async function onImport(file) {
		if (!file) return;
		try {
			const parsed = JSON.parse(await file.text());
			if (!parsed || !Array.isArray(parsed.tiers) || !parsed.items || !parsed.placements) throw new Error("Not a Rung list");
			const id = importBoard(parsed);
			toast.success("Imported");
			navigate({
				to: "/b/$boardId",
				params: { boardId: id }
			});
		} catch {
			toast.error("Could not import that file");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex h-14 items-center justify-between px-4 md:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-serif text-2xl tracking-tight",
					children: "Rung"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							ref: fileRef,
							type: "file",
							accept: "application/json",
							className: "hidden",
							onChange: (e) => {
								onImport(e.target.files?.[0]);
								e.target.value = "";
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "ghost",
							size: "sm",
							onClick: () => fileRef.current?.click(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden sm:inline",
								children: "Import"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							onClick: () => setOpen(true),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "New list"]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto grid max-w-6xl gap-10 px-4 py-8 md:grid-cols-[1.1fr_0.9fr] md:px-8 md:py-14",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex flex-col justify-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-3 text-sm font-medium tracking-wide text-muted uppercase",
							children: "Tier lists, on your terms"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "font-serif text-5xl leading-[1.05] tracking-tight md:text-6xl",
							children: [
								"Rank ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", {
									className: "italic",
									children: "anything"
								}),
								".",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								"Name every rung."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-md text-base leading-relaxed text-muted",
							children: "Color the rows, drag in pictures from the web, and keep every list in this browser. No account."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 flex flex-wrap gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "lg",
								onClick: () => setOpen(true),
								children: "Start a list"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "lg",
								variant: "secondary",
								onClick: () => fileRef.current?.click(),
								children: "Import JSON"
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "hidden md:block",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroRungs, {})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto max-w-6xl px-4 pb-16 md:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex items-baseline justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium tracking-wide text-muted uppercase",
						children: "Your lists"
					}), hydrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-subtle tabular-nums",
						children: boards.length
					}) : null]
				}), !hydrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
					children: Array.from({ length: 3 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-36 rounded-lg bg-surface shadow-[var(--shadow-border)]" }, i))
				}) : boards.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setOpen(true),
					className: "flex w-full flex-col items-start gap-2 rounded-lg bg-surface p-5 text-left shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-5 text-muted" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: "No lists yet"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Create one and search the web for pictures to rank."
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
					children: boards.map((board) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/b/$boardId",
							params: { boardId: board.id },
							className: "block rounded-lg bg-surface p-4 shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniRungs, { board }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 truncate font-medium",
									children: board.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted",
									children: [
										Object.keys(board.items).length,
										" items · ",
										formatUpdated(board.updatedAt)
									]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute top-2 right-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "inline-flex size-9 items-center justify-center rounded-sm bg-surface/80 text-muted hover:bg-surface-2 hover:text-fg",
									"aria-label": `${board.title} menu`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, { className: "size-4" })
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
								align: "end",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
									onSelect: () => {
										if (duplicateBoard(board.id)) toast.success("Duplicated");
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), "Duplicate"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
									className: "text-danger",
									onSelect: () => {
										if (window.confirm(`Delete “${board.title}”?`)) deleteBoard(board.id);
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), "Delete"]
								})]
							})] })
						})]
					}, board.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NewBoardDialog, {
				open,
				onOpenChange: setOpen
			})
		]
	});
}
var SplitComponent = HomePage;
//#endregion
export { SplitComponent as component };
