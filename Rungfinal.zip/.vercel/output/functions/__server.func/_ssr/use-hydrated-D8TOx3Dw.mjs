import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime, r as Slot } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
import { a as Separator2, i as Root2, n as Item2, o as Trigger, r as Portal2, t as Content2 } from "../_libs/@radix-ui/react-dropdown-menu+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/use-hydrated-D8TOx3Dw.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid() {
	return crypto.randomUUID();
}
function slugify(value) {
	return value.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "") || "list";
}
function formatUpdated(ts) {
	const delta = Date.now() - ts;
	const minute = 6e4;
	const hour = 60 * minute;
	const day = 24 * hour;
	if (delta < minute) return "Just now";
	if (delta < hour) return `${Math.floor(delta / minute)}m ago`;
	if (delta < day) return `${Math.floor(delta / hour)}h ago`;
	if (delta < 7 * day) return `${Math.floor(delta / day)}d ago`;
	return new Date(ts).toLocaleDateString(void 0, {
		month: "short",
		day: "numeric"
	});
}
var TEMPLATES = [
	{
		id: "classic",
		name: "Classic",
		hint: "S through F",
		tiers: [
			{
				name: "S",
				color: "#e85d4c"
			},
			{
				name: "A",
				color: "#e89a4c"
			},
			{
				name: "B",
				color: "#e8c84c"
			},
			{
				name: "C",
				color: "#7dbe6a"
			},
			{
				name: "D",
				color: "#5aa0d6"
			},
			{
				name: "F",
				color: "#8b86a8"
			}
		]
	},
	{
		id: "five",
		name: "Five rungs",
		hint: "Loved to no",
		tiers: [
			{
				name: "Loved",
				color: "#e85d4c"
			},
			{
				name: "Liked",
				color: "#e89a4c"
			},
			{
				name: "Fine",
				color: "#e8c84c"
			},
			{
				name: "Meh",
				color: "#5aa0d6"
			},
			{
				name: "No",
				color: "#8b86a8"
			}
		]
	},
	{
		id: "verdict",
		name: "Verdict",
		hint: "Keep, maybe, pass",
		tiers: [
			{
				name: "Keep",
				color: "#2f9e7b"
			},
			{
				name: "Maybe",
				color: "#e8c84c"
			},
			{
				name: "Pass",
				color: "#8b86a8"
			}
		]
	},
	{
		id: "blank",
		name: "Blank",
		hint: "One empty rung",
		tiers: [{
			name: "New",
			color: "#4a4a4e"
		}]
	}
];
function makeTiers(templateId = "classic") {
	return (TEMPLATES.find((t) => t.id === templateId) ?? TEMPLATES[0]).tiers.map((tier) => ({
		id: uid(),
		name: tier.name,
		color: tier.color
	}));
}
var UNRANKED = "unranked";
var MAX_ITEMS = 160;
var MAX_TIERS = 12;
function touch(board) {
	return {
		...board,
		updatedAt: Date.now()
	};
}
function patch(boards, id, fn) {
	const current = boards[id];
	if (!current) return { boards };
	return { boards: {
		...boards,
		[id]: touch(fn(current))
	} };
}
var useBoardStore = create()(persist((set, get) => ({
	boards: {},
	createBoard: (title, template) => {
		const id = uid();
		const now = Date.now();
		const tiers = makeTiers(template);
		const placements = { [UNRANKED]: [] };
		for (const tier of tiers) placements[tier.id] = [];
		const board = {
			id,
			title: title.trim() || "Untitled",
			createdAt: now,
			updatedAt: now,
			tiers,
			items: {},
			placements
		};
		set((s) => ({ boards: {
			...s.boards,
			[id]: board
		} }));
		return id;
	},
	duplicateBoard: (id) => {
		const source = get().boards[id];
		if (!source) return null;
		const nextId = uid();
		const now = Date.now();
		const tierIdMap = /* @__PURE__ */ new Map();
		const tiers = source.tiers.map((tier) => {
			const newId = uid();
			tierIdMap.set(tier.id, newId);
			return {
				...tier,
				id: newId
			};
		});
		const itemIdMap = /* @__PURE__ */ new Map();
		const items = {};
		for (const item of Object.values(source.items)) {
			const newId = uid();
			itemIdMap.set(item.id, newId);
			items[newId] = {
				...item,
				id: newId
			};
		}
		const remap = (ids) => ids.map((old) => itemIdMap.get(old)).filter((x) => Boolean(x));
		const placements = { [UNRANKED]: remap(source.placements["unranked"] ?? []) };
		for (const tier of source.tiers) {
			const newTierId = tierIdMap.get(tier.id);
			if (!newTierId) continue;
			placements[newTierId] = remap(source.placements[tier.id] ?? []);
		}
		set((s) => ({ boards: {
			...s.boards,
			[nextId]: {
				...source,
				id: nextId,
				title: `${source.title} copy`,
				createdAt: now,
				updatedAt: now,
				tiers,
				items,
				placements
			}
		} }));
		return nextId;
	},
	deleteBoard: (id) => {
		set((s) => {
			const { [id]: _, ...rest } = s.boards;
			return { boards: rest };
		});
	},
	importBoard: (incoming) => {
		const id = uid();
		const now = Date.now();
		const board = {
			...incoming,
			id,
			createdAt: now,
			updatedAt: now,
			title: incoming.title?.trim() || "Imported"
		};
		set((s) => ({ boards: {
			...s.boards,
			[id]: board
		} }));
		return id;
	},
	setTitle: (id, title) => {
		set((s) => patch(s.boards, id, (b) => ({
			...b,
			title: title.trim() || "Untitled"
		})));
	},
	setTierName: (boardId, tierId, name) => {
		set((s) => patch(s.boards, boardId, (b) => ({
			...b,
			tiers: b.tiers.map((t) => t.id === tierId ? {
				...t,
				name: name.slice(0, 18)
			} : t)
		})));
	},
	setTierColor: (boardId, tierId, color) => {
		set((s) => patch(s.boards, boardId, (b) => ({
			...b,
			tiers: b.tiers.map((t) => t.id === tierId ? {
				...t,
				color
			} : t)
		})));
	},
	addTier: (boardId) => {
		set((s) => patch(s.boards, boardId, (b) => {
			if (b.tiers.length >= MAX_TIERS) return b;
			const id = uid();
			return {
				...b,
				tiers: [...b.tiers, {
					id,
					name: "New",
					color: "#4a4a4e"
				}],
				placements: {
					...b.placements,
					[id]: []
				}
			};
		}));
	},
	removeTier: (boardId, tierId) => {
		set((s) => patch(s.boards, boardId, (b) => {
			if (b.tiers.length <= 1) return b;
			const moved = b.placements[tierId] ?? [];
			const { [tierId]: _, ...rest } = b.placements;
			return {
				...b,
				tiers: b.tiers.filter((t) => t.id !== tierId),
				placements: {
					...rest,
					[UNRANKED]: [...rest["unranked"] ?? [], ...moved]
				}
			};
		}));
	},
	moveTier: (boardId, tierId, direction) => {
		set((s) => patch(s.boards, boardId, (b) => {
			const index = b.tiers.findIndex((t) => t.id === tierId);
			if (index < 0) return b;
			const next = [...b.tiers];
			const swap = direction === "up" ? index - 1 : index + 1;
			if (swap < 0 || swap >= next.length) return b;
			const tmp = next[index];
			next[index] = next[swap];
			next[swap] = tmp;
			return {
				...b,
				tiers: next
			};
		}));
	},
	addItem: (boardId, item, zone = UNRANKED) => {
		const board = get().boards[boardId];
		if (!board) return null;
		if (Object.keys(board.items).length >= MAX_ITEMS) return null;
		const id = uid();
		const dest = zone in board.placements ? zone : UNRANKED;
		set((s) => patch(s.boards, boardId, (b) => ({
			...b,
			items: {
				...b.items,
				[id]: {
					...item,
					id
				}
			},
			placements: {
				...b.placements,
				[dest]: [...b.placements[dest] ?? [], id]
			}
		})));
		return id;
	},
	removeItem: (boardId, itemId) => {
		set((s) => patch(s.boards, boardId, (b) => {
			const { [itemId]: _, ...items } = b.items;
			const placements = Object.fromEntries(Object.entries(b.placements).map(([k, ids]) => [k, ids.filter((id) => id !== itemId)]));
			return {
				...b,
				items,
				placements
			};
		}));
	},
	renameItem: (boardId, itemId, label) => {
		set((s) => patch(s.boards, boardId, (b) => {
			const item = b.items[itemId];
			if (!item) return b;
			return {
				...b,
				items: {
					...b.items,
					[itemId]: {
						...item,
						label: label.slice(0, 48)
					}
				}
			};
		}));
	},
	moveItem: (boardId, itemId, destZone, destIndex) => {
		set((s) => patch(s.boards, boardId, (b) => {
			if (!b.items[itemId]) return b;
			const zone = destZone in b.placements ? destZone : UNRANKED;
			const placements = {};
			let fromIndex = -1;
			let fromZone = UNRANKED;
			for (const [key, ids] of Object.entries(b.placements)) placements[key] = ids.filter((id, i) => {
				if (id === itemId) {
					fromIndex = i;
					fromZone = key;
					return false;
				}
				return true;
			});
			const list = [...placements[zone] ?? []];
			let index = destIndex;
			if (fromZone === zone && fromIndex >= 0 && fromIndex < index) index -= 1;
			index = Math.max(0, Math.min(index, list.length));
			list.splice(index, 0, itemId);
			placements[zone] = list;
			return {
				...b,
				placements
			};
		}));
	},
	resetRanks: (boardId) => {
		set((s) => patch(s.boards, boardId, (b) => {
			const all = Object.keys(b.items);
			const placements = { [UNRANKED]: all };
			for (const tier of b.tiers) placements[tier.id] = [];
			return {
				...b,
				placements
			};
		}));
	}
}), {
	name: "rung-boards-v1",
	storage: createJSONStorage(() => {
		if (typeof window === "undefined") return {
			getItem: () => null,
			setItem: () => {},
			removeItem: () => {}
		};
		return localStorage;
	}),
	partialize: (s) => ({ boards: s.boards }),
	skipHydration: true
}));
function listBoards(boards) {
	return Object.values(boards).sort((a, b) => b.updatedAt - a.updatedAt);
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-[transform,background-color,color,opacity,box-shadow] duration-150 ease-out select-none disabled:pointer-events-none disabled:opacity-40 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg hover:opacity-90",
			secondary: "bg-surface-2 text-fg shadow-[var(--shadow-border)] hover:bg-surface",
			outline: "text-fg shadow-[var(--shadow-border)] hover:bg-surface-2",
			ghost: "text-fg hover:bg-surface-2",
			danger: "bg-danger text-fg hover:opacity-90"
		},
		size: {
			default: "h-11 rounded-sm px-4 text-sm",
			sm: "h-9 rounded-sm px-3 text-sm",
			lg: "h-12 rounded-md px-5 text-sm",
			icon: "size-11 rounded-sm",
			"icon-sm": "size-9 rounded-sm"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("h-11 w-full rounded-sm bg-surface-2 px-3 text-sm text-fg shadow-[var(--shadow-border)] outline-none placeholder:text-subtle", "transition-[box-shadow] duration-150 ease-out", "focus-visible:shadow-[var(--shadow-border-hover)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent", className),
		...props
	});
}
var DropdownMenu = Root2;
var DropdownMenuTrigger = Trigger;
function DropdownMenuContent({ className, sideOffset = 6, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal2, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
		sideOffset,
		className: cn("z-50 min-w-44 overflow-hidden rounded-md bg-surface-2 p-1 shadow-[var(--shadow-border)]", "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95", className),
		...props
	}) });
}
function DropdownMenuItem({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item2, {
		className: cn("flex cursor-pointer items-center gap-2 rounded-xs px-2 py-2 text-sm text-fg outline-none select-none", "focus:bg-surface data-[disabled]:pointer-events-none data-[disabled]:opacity-40", className),
		...props
	});
}
function DropdownMenuSeparator({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator2, {
		className: cn("my-1 h-px bg-border", className),
		...props
	});
}
var BATMAN_BOARD_ID = "rung-seed-batman-movies";
var FILMS = [
	{
		id: "bat-1966",
		label: "Batman (1966)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/6/69/Batman1966Poster.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman_(1966_film)"
	},
	{
		id: "bat-1989",
		label: "Batman (1989)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/5/5a/Batman_%281989%29_theatrical_poster.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman_(1989_film)"
	},
	{
		id: "bat-returns",
		label: "Batman Returns (1992)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/8/83/Batman_returns_poster2.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman_Returns"
	},
	{
		id: "bat-phantasm",
		label: "Batman: Mask of the Phantasm (1993)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/e/ea/Batman_mask_of_the_phantasm_poster.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman:_Mask_of_the_Phantasm"
	},
	{
		id: "bat-forever",
		label: "Batman Forever (1995)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/9/9d/Batman_Forever_poster.png",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman_Forever"
	},
	{
		id: "bat-robin",
		label: "Batman & Robin (1997)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/3/37/Batman_%26_Robin_poster.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman_%26_Robin_(film)"
	},
	{
		id: "bat-subzero",
		label: "Batman & Mr. Freeze: SubZero (1998)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/4/47/Batman_%26_Mr._Freeze_SubZero.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman_%26_Mr._Freeze:_SubZero"
	},
	{
		id: "bat-beyond-joker",
		label: "Batman Beyond: Return of the Joker (2000)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/f/fd/Batman_Beyond_-_Return_of_the_Joker_poster.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman_Beyond:_Return_of_the_Joker"
	},
	{
		id: "bat-batwoman",
		label: "Batman: Mystery of the Batwoman (2003)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/7/7f/Batman-Mystery_of_the_Batwoman_poster.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman:_Mystery_of_the_Batwoman"
	},
	{
		id: "bat-begins",
		label: "Batman Begins (2005)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/a/af/Batman_Begins_Poster.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman_Begins"
	},
	{
		id: "bat-dracula",
		label: "The Batman vs. Dracula (2005)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/2/2f/Batman_vs._Dracula.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/The_Batman_vs._Dracula"
	},
	{
		id: "bat-tdk",
		label: "The Dark Knight (2008)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/1/1c/The_Dark_Knight_%282008_film%29.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/The_Dark_Knight"
	},
	{
		id: "bat-gotham-knight",
		label: "Batman: Gotham Knight (2008)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/f/f0/Batman_Gotham_Knight.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman:_Gotham_Knight"
	},
	{
		id: "bat-public-enemies",
		label: "Superman/Batman: Public Enemies (2009)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/9/9f/Sup_bat_public_enemies_dvd.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Superman/Batman:_Public_Enemies"
	},
	{
		id: "bat-red-hood",
		label: "Batman: Under the Red Hood (2010)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/4/4c/Batman_under_the_red_hood_poster.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman:_Under_the_Red_Hood"
	},
	{
		id: "bat-apocalypse",
		label: "Superman/Batman: Apocalypse (2010)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/f/f2/SBApocalypse.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Superman/Batman:_Apocalypse"
	},
	{
		id: "bat-year-one",
		label: "Batman: Year One (2011)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/8/8b/Bat_year_one_film.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman:_Year_One_(film)"
	},
	{
		id: "bat-tdkr",
		label: "The Dark Knight Rises (2012)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/8/83/Dark_knight_rises_poster.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/The_Dark_Knight_Rises"
	},
	{
		id: "bat-dkr-1",
		label: "Batman: The Dark Knight Returns, Part 1 (2012)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/e/e9/Batman_The_Dark_Knight_Returns_%28film%29.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman:_The_Dark_Knight_Returns_(film)"
	},
	{
		id: "bat-dkr-2",
		label: "Batman: The Dark Knight Returns, Part 2 (2013)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/e/e9/Batman_The_Dark_Knight_Returns_%28film%29.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman:_The_Dark_Knight_Returns_(film)"
	},
	{
		id: "bat-lego-unite",
		label: "LEGO Batman: DC Super Heroes Unite (2013)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/4/43/Legobatman2.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Lego_Batman:_The_Movie_–_DC_Super_Heroes_Unite"
	},
	{
		id: "bat-son",
		label: "Son of Batman (2014)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/2/21/Son_of_Batman_cover.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Son_of_Batman"
	},
	{
		id: "bat-arkham",
		label: "Batman: Assault on Arkham (2014)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/c/c0/Batman_Assault_on_Arkham_cover.jpeg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman:_Assault_on_Arkham"
	},
	{
		id: "bat-vs-robin",
		label: "Batman vs. Robin (2015)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/0/00/Bat_vs_robin_cover.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman_vs._Robin"
	},
	{
		id: "bat-unl-animal",
		label: "Batman Unlimited: Animal Instincts (2015)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/4/43/Batman_animal_instincts.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman_Unlimited:_Animal_Instincts"
	},
	{
		id: "bat-unl-monster",
		label: "Batman Unlimited: Monster Mayhem (2015)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/7/70/Batman_monster_mayhem.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman_Unlimited:_Monster_Mayhem"
	},
	{
		id: "bat-bvs",
		label: "Batman v Superman: Dawn of Justice (2016)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/3/31/Batman_v_Superman_Dawn_of_Justice_poster.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman_v_Superman:_Dawn_of_Justice"
	},
	{
		id: "bat-bad-blood",
		label: "Batman: Bad Blood (2016)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/d/df/Batman_Bad_Blood_cover.jpeg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman:_Bad_Blood"
	},
	{
		id: "bat-killing-joke",
		label: "Batman: The Killing Joke (2016)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/1/11/Batman-The_Killing_Joke_%28film%29.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman:_The_Killing_Joke_(film)"
	},
	{
		id: "bat-unl-mechs",
		label: "Batman Unlimited: Mechs vs. Mutants (2016)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/8/8a/Mechs-vs-Mutants-2D-600x790.jpeg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman_Unlimited:_Mechs_vs._Mutants"
	},
	{
		id: "bat-caped-crusaders",
		label: "Batman: Return of the Caped Crusaders (2016)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/c/cb/Batman-_Return_of_the_Caped_Crusaders.jpeg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman:_Return_of_the_Caped_Crusaders"
	},
	{
		id: "bat-jl",
		label: "Justice League (2017)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/6/6b/Justice_League_%28film%29_poster.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Justice_League_(film)"
	},
	{
		id: "bat-lego",
		label: "The Lego Batman Movie (2017)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/6/61/The_Lego_Batman_Movie_PromotionalPoster.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/The_Lego_Batman_Movie"
	},
	{
		id: "bat-harley",
		label: "Batman and Harley Quinn (2017)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/b/b9/Batman_and_Harley_Quinn_movie_poster.jpeg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman_and_Harley_Quinn"
	},
	{
		id: "bat-two-face",
		label: "Batman vs. Two-Face (2017)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/d/da/Batman_vs_Two-Face_cover.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman_vs._Two-Face"
	},
	{
		id: "bat-scooby",
		label: "Scooby-Doo! & Batman: The Brave and the Bold (2018)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/9/9e/SCOOBY_BM_BATB_AMRY_2D_1000692058.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Scooby-Doo!_%26_Batman:_The_Brave_and_the_Bold"
	},
	{
		id: "bat-gaslight",
		label: "Batman: Gotham by Gaslight (2018)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/c/cf/Gotham_gaslight_blueray.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman:_Gotham_by_Gaslight"
	},
	{
		id: "bat-ninja",
		label: "Batman Ninja (2018)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/9/91/Batman-ninja---blu-ray-cover-1518549457339_1280w.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman_Ninja"
	},
	{
		id: "bat-joker",
		label: "Joker (2019)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/e/e1/Joker_%282019_film%29_poster.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Joker_(2019_film)"
	},
	{
		id: "bat-tmnt",
		label: "Batman vs. Teenage Mutant Ninja Turtles (2019)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/1/19/Batman_Ninja_Turtles_Cover.png",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman_vs._Teenage_Mutant_Ninja_Turtles"
	},
	{
		id: "bat-hush",
		label: "Batman: Hush (2019)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/e/e0/Batman_Hush_4K_Ultra_HD_Blu-ray_cover.jpeg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman:_Hush_(film)"
	},
	{
		id: "bat-family-matters",
		label: "LEGO DC Batman: Family Matters (2019)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/6/62/Batman_lego_family_matters.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Lego_DC_Batman:_Family_Matters"
	},
	{
		id: "bat-ditf",
		label: "Batman: Death in the Family (2020)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/2/2d/Batman_Death_in_the_Family.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman:_Death_in_the_Family"
	},
	{
		id: "bat-zsjl",
		label: "Zack Snyder's Justice League (2021)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/6/60/Zack_Snyder%27s_Justice_League.png",
		sourceUrl: "https://en.wikipedia.org/wiki/Zack_Snyder's_Justice_League"
	},
	{
		id: "bat-soul",
		label: "Batman: Soul of the Dragon (2021)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/e/e7/Batman_Soul_of_the_Dragon_film_Blu-ray.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman:_Soul_of_the_Dragon"
	},
	{
		id: "bat-tlh-1",
		label: "Batman: The Long Halloween, Part One (2021)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/0/0a/Batman_The_Long_Halloween_4k.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman:_The_Long_Halloween_(film)"
	},
	{
		id: "bat-tlh-2",
		label: "Batman: The Long Halloween, Part Two (2021)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/0/0a/Batman_The_Long_Halloween_4k.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman:_The_Long_Halloween_(film)"
	},
	{
		id: "bat-2022",
		label: "The Batman (2022)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/f/ff/The_Batman_%28film%29_poster.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/The_Batman_(film)"
	},
	{
		id: "bat-super-sons",
		label: "Batman and Superman: Battle of the Super Sons (2022)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/c/c1/Batman_and_Superman_Battle_of_the_Super_Sons_poster.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman_and_Superman:_Battle_of_the_Super_Sons"
	},
	{
		id: "bat-flash",
		label: "The Flash (2023)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/e/ed/The_Flash_%28film%29_poster.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/The_Flash_(film)"
	},
	{
		id: "bat-doom",
		label: "Batman: The Doom That Came to Gotham (2023)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/1/10/Batman_The_Doom_That_Came_to_Gotham_issue_1.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman:_The_Doom_That_Came_to_Gotham"
	},
	{
		id: "bat-merry",
		label: "Merry Little Batman (2023)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/1/16/Merry_Little_Batman_poster.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Merry_Little_Batman"
	},
	{
		id: "bat-folie",
		label: "Joker: Folie à Deux (2024)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/e/e8/Joker_-_Folie_%C3%A0_Deux_poster.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Joker:_Folie_à_Deux"
	},
	{
		id: "bat-aztec",
		label: "Aztec Batman: Clash of Empires (2025)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/e/e9/Aztec_Batman_Clash_of_Empires_poster.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Aztec_Batman:_Clash_of_Empires"
	},
	{
		id: "bat-yakuza",
		label: "Batman Ninja vs. Yakuza League (2025)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/3/3b/Batman_Ninja_vs._Yakuza_League_poster.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman_Ninja_vs._Yakuza_League"
	},
	{
		id: "bat-knightfall",
		label: "Batman: Knightfall Part 1 (2026)",
		imageUrl: "https://upload.wikimedia.org/wikipedia/en/9/90/BatmanKnightfallTrilogyLogo.jpg",
		sourceUrl: "https://en.wikipedia.org/wiki/Batman:_Knightfall_(film)"
	}
];
function buildBatmanBoard() {
	const now = Date.now();
	const tiers = makeTiers("classic");
	const items = {};
	const order = [];
	for (const film of FILMS) {
		items[film.id] = {
			id: film.id,
			label: film.label,
			imageUrl: film.imageUrl,
			sourceUrl: film.sourceUrl
		};
		order.push(film.id);
	}
	const placements = { [UNRANKED]: order };
	for (const tier of tiers) placements[tier.id] = [];
	return {
		id: BATMAN_BOARD_ID,
		title: "Batman movies",
		createdAt: now,
		updatedAt: now,
		tiers,
		items,
		placements
	};
}
function seedBatman() {
	const { boards } = useBoardStore.getState();
	if (boards["rung-seed-batman-movies"]) return;
	useBoardStore.setState({ boards: {
		...boards,
		[BATMAN_BOARD_ID]: buildBatmanBoard()
	} });
}
function useHydrated() {
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		const persist = useBoardStore.persist;
		const finish = () => {
			if (cancelled) return;
			seedBatman();
			setHydrated(true);
		};
		if (!persist) {
			finish();
			return;
		}
		const unsub = persist.onFinishHydration(finish);
		if (persist.hasHydrated()) finish();
		else persist.rehydrate();
		return () => {
			cancelled = true;
			unsub?.();
		};
	}, []);
	return hydrated;
}
//#endregion
export { DropdownMenuSeparator as a, TEMPLATES as c, formatUpdated as d, listBoards as f, useHydrated as h, DropdownMenuItem as i, UNRANKED as l, useBoardStore as m, DropdownMenu as n, DropdownMenuTrigger as o, slugify as p, DropdownMenuContent as r, Input as s, Button as t, cn as u };
