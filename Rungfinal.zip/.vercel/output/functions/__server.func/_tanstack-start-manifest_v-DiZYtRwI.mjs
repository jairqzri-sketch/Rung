//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DiZYtRwI.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/b/$boardId"],
		preloads: ["/assets/index-CX-HXjMl.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CX-HXjMl.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-TJ46H3qV.js", "/assets/use-hydrated-BEk7I0vT.js"]
	},
	"/b/$boardId": {
		filePath: "/workspace/src/routes/b.$boardId.tsx",
		children: void 0,
		preloads: ["/assets/b._boardId-CQM5r1b1.js", "/assets/use-hydrated-BEk7I0vT.js"]
	}
} });
//#endregion
export { tsrStartManifest };
